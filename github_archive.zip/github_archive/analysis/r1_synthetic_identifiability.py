#!/usr/bin/env python3
"""Frozen S0--S3 population identifiability experiment.

The experiment uses the same population fitter as the selection Monte Carlo.
It is intentionally modest: it tests model-selection power and false
preference under a fixed grid, while documenting that the star-level estimator
is represented by a fixed completeness-dependent perturbation calibrated from
the existing selection design, not by a new physical model.
"""
from __future__ import annotations
import argparse, json
from pathlib import Path
import sys
import numpy as np
import pandas as pd
import yaml

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from selection_function_mc_analysis import fast_single_broken_fit


def environment_recovery(age: np.ndarray, env: np.ndarray, y: np.ndarray) -> tuple[float, float]:
    x = np.column_stack([np.ones(len(age)), np.log10(age / 100.0)])
    beta_age = np.linalg.lstsq(x, y, rcond=None)[0]
    xa = np.column_stack([x, env])
    beta = np.linalg.lstsq(xa, y, rcond=None)[0]
    # A predeclared, amplitude-scale criterion, used for all scenarios.
    recovered = bool(np.sign(beta[2]) > 0 and abs(beta[2]) >= 0.20)
    return float(beta[2]), float(recovered)


def run(cfg: dict) -> pd.DataFrame:
    rng = np.random.default_rng(int(cfg["seed"]))
    actual_ages = pd.read_csv("outputs_v3/cluster_population.csv")["age_Myr"].to_numpy(float)
    rows = []
    for scenario, pars in cfg["scenarios"].items():
        for c in cfg["rv_completeness_grid"]:
            rec = []
            env_rec = []
            for rep in range(int(cfg["n_population_replicates"])):
                age = rng.choice(actual_ages, int(cfg["n_clusters"]), replace=True)
                env = rng.normal(0.0, 1.0, int(cfg["n_clusters"]))
                x = np.log10(age / 100.0)
                mu = -1.30 + float(pars["age_slope"]) * x
                if pars.get("broken", False):
                    mu += float(cfg["break_slope_change"]) * np.maximum(0.0, x - np.log10(float(cfg["break_age_Myr"]) / 100.0))
                mu += float(pars.get("environment_effect", 0.0)) * env
                true_y = mu + rng.normal(0.0, float(cfg["intrinsic_scatter_logit"]), len(age))
                # Fixed forward perturbation: incompleteness adds estimator noise
                # with no post-hoc amplitude tuning.
                sel_sd = 0.95 * (1.0 - float(c))
                y = true_y + rng.normal(0.0, float(cfg["measurement_error_logit"]), len(age)) + rng.normal(0.0, sel_sd, len(age))
                fit_df = pd.DataFrame({"age_Myr": age, "logit_f_L": y, "logit_f_L_err": np.full(len(age), float(cfg["measurement_error_logit"])), "f_L_v2": 1.0 / (1.0 + np.exp(-np.clip(y, -50, 50)))})
                fit = fast_single_broken_fit(fit_df)
                env_beta, env_ok = environment_recovery(age, env, y)
                rec.append({**fit, "env_beta": env_beta, "env_ok": env_ok, "true_sigma": float(cfg["intrinsic_scatter_logit"])})
            rd = pd.DataFrame(rec)
            injected = float(cfg["intrinsic_scatter_logit"])
            rows.append({"scenario": scenario, "injected_parameters": json.dumps(pars, sort_keys=True), "RV_completeness": float(c), "N": len(rd), "single_selected_fraction": 1.0 - float(np.mean(rd.delta_bic_broken_vs_single < 0)), "broken_selected_fraction": float(np.mean(rd.delta_bic_broken_vs_single < 0)), "strong_broken_fraction": float(np.mean(rd.delta_bic_broken_vs_single < -6)), "environment_recovery_fraction": float(np.mean(rd.env_ok)) if float(pars.get("environment_effect", 0.0)) != 0 else float(np.mean(rd.env_ok)), "bias": float(np.mean(rd.sigma_int_single - injected)), "RMSE": float(np.sqrt(np.mean((rd.sigma_int_single - injected) ** 2))), "median_sigma_int": float(np.median(rd.sigma_int_single)), "median_delta_BIC": float(np.median(rd.delta_bic_broken_vs_single)), "median_environment_coefficient": float(np.median(rd.env_beta))})
    return pd.DataFrame(rows)


def main() -> None:
    ap = argparse.ArgumentParser(); ap.add_argument("--config", type=Path, default=Path("revision/freeze/R1_SYNTHETIC_SCENARIOS.yaml")); ap.add_argument("--outdir", type=Path, default=Path("results/r1")); args=ap.parse_args(); args.outdir.mkdir(parents=True, exist_ok=True)
    cfg = yaml.safe_load(args.config.read_text()); out = run(cfg); out.to_csv(args.outdir / "synthetic_identifiability.csv", index=False); (args.outdir / "synthetic_identifiability_config.json").write_text(json.dumps(cfg, indent=2)); print(f"Wrote {len(out)} frozen synthetic scenario/completeness summaries")


if __name__ == "__main__": main()
