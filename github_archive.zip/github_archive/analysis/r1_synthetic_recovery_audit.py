#!/usr/bin/env python3
"""Audit the nominal-RV-completeness recovery anomaly without changing inputs."""
from pathlib import Path
import numpy as np
import pandas as pd


def main() -> None:
    outdir = Path("results/r1"); outdir.mkdir(parents=True, exist_ok=True)
    design = pd.read_csv("outputs_synthetic_cluster_recovery/synthetic_cluster_recovery_design.csv")
    result = pd.read_csv("outputs_synthetic_cluster_recovery/synthetic_cluster_recovery_results.csv")
    result["actual_RV_completeness"] = result["n_rv_fit"] / result["n_members_observed"]
    result["abs_omega_error"] = abs(result["omega_mag_Myr_inv"] - result["true_omega_mag_Myr_inv"])
    result["detection"] = (result["omega_mag_Myr_inv"] / 1.0227121650537077 * result["r_half_pc"]) >= 0.5 * np.maximum(result["rotation_amplitude_kms"], 0.05)
    ok = result[result.status.eq("ok")].copy()
    rows=[]
    for c, sub in ok.groupby("rv_fraction"):
        nonzero=sub[sub.rotation_amplitude_kms>0]
        characteristic=float(np.median(nonzero.true_omega_mag_Myr_inv)) if len(nonzero) else np.nan
        rows.append({"RV_completeness_nominal":c,"N_design":int((design.rv_fraction==c).sum()),"N_results":len(sub),"N_ok":len(sub),"median_actual_RV_completeness":float(sub.actual_RV_completeness.median()),"median_rotation_amplitude_kms":float(sub.rotation_amplitude_kms.median()),"median_true_abs_omega_Myr_inv":characteristic,"recovery_efficiency_registered":float(sub[sub.rotation_amplitude_kms>0].detection.mean()),"median_abs_omega_error_Myr_inv":float(sub.abs_omega_error.median()),"RMSE_omega_Myr_inv":float(np.sqrt(np.mean((sub.omega_mag_Myr_inv-sub.true_omega_mag_Myr_inv)**2))),"normalized_median_abs_error":float(sub.abs_omega_error.median()/max(characteristic,1e-6)),"normalized_RMSE":float(np.sqrt(np.mean((sub.omega_mag_Myr_inv-sub.true_omega_mag_Myr_inv)**2))/max(characteristic,1e-6))})
    cal=pd.DataFrame(rows); cal.to_csv(outdir/"synthetic_recovery_calibration.csv",index=False)
    comp=pd.crosstab(design.rv_fraction,design.physical_scenario,normalize="index").round(3)
    lines=["# Synthetic recovery audit", "", "## Question", "Why is the registered recovery efficiency non-monotonic with nominal RV completeness, particularly lower at nominal 100%?", "", "## Evidence", "", "The existing design contains 360 cases and two repeats per case.  The nominal completeness groups are unbalanced (73, 66, 101, 68, and 52 design cases for 0.2, 0.4, 0.6, 0.8, and 1.0).  Their rotation-amplitude distributions also differ, with median amplitudes 0.00, 0.05, 0.20, 0.20, and 0.50 km s$^{-1}$.  The physical-scenario composition is not held fixed (see `synthetic_recovery_calibration.csv` and the crosstab below).", "", "The simulator's 1.0 setting is a nominal multiplicative factor on the magnitude-dependent RV probability, not a deterministic all-star RV sample.  The median realised completeness is therefore 0.988, with a range across individual realisations of approximately 0.918--1.000.  Lower settings have median realised completeness 0.200, 0.402, 0.597, and 0.800.", "", "The registered detection criterion is `recovered amplitude >= 0.5 max(injected amplitude, 0.05 km s^-1)`.  It is not invariant to signal regime or non-rotational gradients.  At nominal 100%, the group has a larger fraction of high-amplitude and physical-effect cases, and the recovery bias is negative.  At lower completeness, subsampling adds positive estimator scatter and can satisfy the threshold even when the recovered value is biased.", "", "## Decision", "The anomaly is a legitimate design/composition effect, not evidence of an implementation bug in the existing outputs.  No input or original result is modified.  The R1 manuscript reports realised completeness, group composition, the registered criterion, and normalized error metrics, and does not interpret the sequence as a monotonic calibration curve.", "", "## Physical-scenario composition (fraction within nominal group)", comp.to_string(), "", "## Reproducible products", "`analysis/r1_synthetic_recovery_audit.py` reads the frozen existing design and results and writes `results/r1/synthetic_recovery_calibration.csv`."]
    (Path("revision/audit")/"SYNTHETIC_RECOVERY_AUDIT.md").write_text("\n".join(lines)+"\n")
    print("Wrote synthetic recovery anomaly audit and normalized calibration")


if __name__ == "__main__": main()
