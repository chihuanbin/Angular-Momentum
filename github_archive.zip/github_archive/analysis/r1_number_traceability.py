#!/usr/bin/env python3
"""Generate manuscript-number traceability from machine-readable R1 outputs."""
from __future__ import annotations
import csv
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "revision/audit/R1_NUMBER_TRACEABILITY.csv"
age = pd.read_csv(ROOT / "results/r1/age_width_model_comparison.csv")
flex = pd.read_csv(ROOT / "results/r1/flexible_age_model.csv")
mc = pd.read_csv(ROOT / "results/r1/age_uncertainty_sensitivity.csv")
tr = pd.read_csv(ROOT / "results/r1/transform_robustness.csv")
env = pd.read_csv(ROOT / "results/r1/environment_predictive_comparison.csv")
sel = pd.read_csv(ROOT / "results/r1/selection_scatter_summary.csv")
synth = pd.read_csv(ROOT / "results/r1/synthetic_identifiability.csv")
ext = pd.read_csv(ROOT / "outputs_independent_validation_sampling/sampling_consistency_result_table.csv")
pop = pd.read_csv(ROOT / "outputs_v3/cluster_population.csv")
narrow = pd.read_csv(ROOT / "results/r1/narrow_sequence_bic_audit.csv")
null = pd.read_csv(ROOT / "results/r1/constant_vs_age_model.csv")
null_summary = pd.read_csv(ROOT / "results/r1/age_slope_summary.csv").iloc[0]
null_cv = pd.read_csv(ROOT / "results/r1/constant_vs_age_cv.csv")

def one(cid, section, text, quantity, value, units, source_csv, source_column, script, figtab):
    return {"claim_id":cid, "manuscript_section":section, "manuscript_text":text,
            "quantity":quantity, "value":value, "units":units, "source_csv":source_csv,
            "source_column":source_column, "script":script, "figure_or_table":figtab}

single = age[age.model.eq("single")].iloc[0]
broken = age[age.model.eq("broken")].iloc[0]
sig0 = narrow[(narrow["dataset"].eq("baseline_status_ok")) & (narrow["transform"].eq("logit(f_L)")) & (narrow["model"].eq("single_sigma0"))].iloc[0]
logn = narrow[(narrow["dataset"].eq("baseline_status_ok")) & (narrow["transform"].eq("log(f_L)")) & (narrow["model"].eq("single_sigma0"))].iloc[0]
lam = ext[ext["survey"].eq("LAMOST")].iloc[0]
sel20 = sel[(sel.scenario.eq("selection_only_null")) & (sel.selection_mode.eq("magnitude_weighted")) & (sel.RV_retention.eq(0.2))].iloc[0]
constant = null[null.model.eq("constant")].iloc[0]
age_null = null[null.model.eq("age")].iloc[0]
cv_constant = null_cv[null_cv.model.eq("constant")].iloc[0]
cv_age = null_cv[null_cv.model.eq("age")].iloc[0]
rows = [
    one("N125","2.1","125 fitted clusters","fitted_clusters",int(single.N),"clusters","results/r1/age_width_model_comparison.csv","N","analysis/r1_age_inference.py","Table 1"),
    one("N114","2.1","114 clusters in the high-quality clean subset","clean_clusters",int((pop.p_good_v3 > 0.7).sum()),"clusters","outputs_v3/cluster_population.csv","p_good_v3","analysis/r1_narrow_sequence_bic_audit.py","Table 1"),
    one("SIGMA3","3.1","fitted intrinsic scatter is 3.00 in logit(f_L)","sigma_int",float(single.sigma_int),"logit(f_L)","results/r1/age_width_model_comparison.csv","sigma_int","analysis/r1_age_inference.py","Table 2"),
    one("BICNARROW","3.1","fixing sigma_int=0 increases the BIC by 2551.6","DeltaBIC_sigma0_minus_positive",float(sig0.DeltaBIC_sigma0_minus_positive),"BIC units","results/r1/narrow_sequence_bic_audit.csv","DeltaBIC_sigma0_minus_positive","analysis/r1_narrow_sequence_bic_audit.py","Table 2"),
    one("BICSIMPLEBREAK","3.1","broken-single Delta BIC is 7.01","delta_BIC",float(broken.delta_BIC),"BIC units","results/r1/age_width_model_comparison.csv","delta_BIC","analysis/r1_age_inference.py","Table 2"),
    one("SIGMAFLEX","3.1","fixed spline leaves comparable width 2.96","sigma_int",float(flex.sigma_int.iloc[0]),"logit(f_L)","results/r1/flexible_age_model.csv","sigma_int","analysis/r1_age_inference.py","Fig. 2/Table 2"),
    one("BICAGEUNC","3.1","catalogue-interval sensitivity median broken-single Delta BIC=7.72","median_delta_BIC_broken_single",float(mc[(mc["dataset"].eq("catalogue_age_MC")) & (mc["model"].eq("broken")) & (mc["quantity"].eq("delta_BIC_broken_single"))]["median"].iloc[0]),"BIC units","results/r1/age_uncertainty_sensitivity.csv","median","analysis/r1_age_inference.py","Fig. 3"),
    one("BICLOG","3.1","log transform broken-single Delta BIC=4.64","delta_BIC_broken_single",float(tr[tr["transform"].eq("log(f_L)")]["delta_BIC_broken_single"].iloc[0]),"BIC units","results/r1/transform_robustness.csv","delta_BIC_broken_single","analysis/r1_transform_robustness.py","Fig. 3"),
    one("BICLOGNARROW","3.1","log transform sigma_int=0 Delta BIC=386.38","DeltaBIC_sigma0_minus_positive",float(logn.DeltaBIC_sigma0_minus_positive),"BIC units","results/r1/narrow_sequence_bic_audit.csv","DeltaBIC_sigma0_minus_positive","analysis/r1_narrow_sequence_bic_audit.py","Fig. 3"),
    one("ENVDR2","3.2","age plus environment changes held-out R2 by -0.027","delta_R2_vs_age_only",float(env[env["model"].eq("age_plus_environment")]["delta_R2_vs_age_only"].iloc[0]),"R2","results/r1/environment_predictive_comparison.csv","delta_R2_vs_age_only","analysis/r1_environment_prediction.py","Table 3"),
    one("SELSIGMA","3.3","20% magnitude-weighted selection-only retention gives sigma_int=4.28","sigma_int_median",float(sel20.sigma_int_median),"logit(f_L)","results/r1/selection_scatter_summary.csv","sigma_int_median (scenario=selection_only_null)","analysis/r1_selection_summary.py","Fig. 5"),
    one("SYNTHFALSE","3.3","smooth S0/S1 broken selection is at most 1.6%","broken_selected_fraction",float(synth[synth.scenario.isin(["S0","S1"])].broken_selected_fraction.max()),"fraction","results/r1/synthetic_identifiability.csv","broken_selected_fraction","analysis/r1_synthetic_identifiability.py","Fig. 6"),
    one("SYNTHPOWER","3.3","specified S2 break recovery is 5.6--11.6%","broken_selected_fraction",f"{100*synth[synth.scenario.eq('S2')].broken_selected_fraction.min():.1f}--{100*synth[synth.scenario.eq('S2')].broken_selected_fraction.max():.1f}","percent","results/r1/synthetic_identifiability.csv","broken_selected_fraction","analysis/r1_synthetic_identifiability.py","Fig. 6"),
    one("LAMCOVER","3.3","25 of 30 LAMOST values lie inside Gaia 95% intervals","coverage_95",float(lam.coverage_95),"fraction","outputs_independent_validation_sampling/sampling_consistency_result_table.csv","coverage_95; validated_clusters","external_rv_data/fetch_external_rv_catalogs.py","Fig. 7"),
    one("LAMSIGMA","3.3","LAMOST sigma_int=3.89 lies inside matched Gaia 2.63--4.55","external_sigma_int; mc_sigma_int_p2_5; mc_sigma_int_p97_5",f"{lam.external_sigma_int:.6f}; {lam.mc_sigma_int_p2_5:.6f}; {lam.mc_sigma_int_p97_5:.6f}","logit(f_L)","outputs_independent_validation_sampling/sampling_consistency_result_table.csv","external_sigma_int; mc_sigma_int_p2_5; mc_sigma_int_p97_5","external_rv_data/fetch_external_rv_catalogs.py","Fig. 7"),
    one("LAMCOUNTS","3.3","five APOGEE, four GALAH, and 30 strict LAMOST matches enter the matched population benchmark","validated_clusters","; ".join(f"{r['survey']}={int(r['validated_clusters'])}" for _,r in ext.iterrows()),"clusters","outputs_independent_validation_sampling/sampling_consistency_result_table.csv","validated_clusters","external_rv_data/fetch_external_rv_catalogs.py","Fig. 7"),
    one("BICAGE_NULL","3.1","constant versus age: Delta BIC constant-age=4.35","delta_BIC_constant_minus_age",float(null_summary.delta_BIC_constant_minus_age),"BIC units","results/r1/age_slope_summary.csv","delta_BIC_constant_minus_age","analysis/r1_constant_age_null.py","Table 2"),
    one("SLOPEAGE_NULL","3.1","age slope is 1.907 with 68% profile interval 1.287--2.529","slope; interval",f"{null_summary.slope_b:.9f}; [{null_summary.slope_interval_lower:.9f}, {null_summary.slope_interval_upper:.9f}]","logit(f_L) per dex","results/r1/age_slope_summary.csv","slope_b; slope_interval_lower; slope_interval_upper","analysis/r1_constant_age_null.py","Table 2"),
    one("CVAGE_NULL","3.1","age-only versus constant held-out RMSE and R2","constant; age RMSE/R2",f"{cv_constant.held_out_RMSE:.6f}/{cv_constant.held_out_R2:.6f}; {cv_age.held_out_RMSE:.6f}/{cv_age.held_out_R2:.6f}","RMSE/R2","results/r1/constant_vs_age_cv.csv","held_out_RMSE; held_out_R2","analysis/r1_constant_age_null.py","Results Sect. 3.1"),
    one("CLEANWIDTH","3.1","clean P(good)>0.7 subset retains zero-width penalty Delta BIC=80.6","DeltaBIC_sigma0_minus_positive",float(narrow[(narrow["dataset"].eq("clean_p_good_gt_0.7")) & (narrow["transform"].eq("logit(f_L)")) & (narrow["model"].eq("single_sigma0"))].iloc[0].DeltaBIC_sigma0_minus_positive),"BIC units","results/r1/narrow_sequence_bic_audit.csv","DeltaBIC_sigma0_minus_positive","analysis/r1_narrow_sequence_bic_audit.py","Fig. 3"),
]

OUT.parent.mkdir(parents=True, exist_ok=True)
with OUT.open("w", newline="", encoding="utf-8") as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
print(f"wrote {len(rows)} traceability rows to {OUT}")
