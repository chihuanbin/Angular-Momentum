#!/usr/bin/env python3
"""R1 mean-shape, residual-width, age-error, and spline checks.

This script consumes the frozen 125-cluster population table and the local
Hunt & Reffert age quantiles.  It never edits the input tables.  The spline is
fixed before fitting (five quantile knots, cubic basis, ridge penalty alpha=1)
and is a specification check rather than a physical model.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import brentq, minimize, minimize_scalar
from sklearn.preprocessing import SplineTransformer


CONV = np.log10(1.0e6)  # age_Myr -> age_yr in log space


def load_data(population: Path, unified: Path) -> pd.DataFrame:
    p = pd.read_csv(population)
    p = p[p["status"].eq("ok")].copy().sort_values("ID").reset_index(drop=True)
    u = pd.read_csv(unified)[["ID", "age_Myr_err_minus", "age_Myr_err_plus"]]
    d = p.merge(u, on="ID", how="left", validate="one_to_one")
    d = d[np.isfinite(d["age_Myr"]) & (d["age_Myr"] > 0) & np.isfinite(d["logit_f_L"]) & np.isfinite(d["logit_f_L_err"])].copy()
    d["x50"] = np.log10(d["age_Myr"].to_numpy(float)) + CONV
    d["age_log_sigma"] = 0.5 * np.log10((d["age_Myr"] + d["age_Myr_err_plus"]) / (d["age_Myr"] - d["age_Myr_err_minus"]))
    d["age_log_sigma"] = d["age_log_sigma"].replace([np.inf, -np.inf], np.nan)
    return d.reset_index(drop=True)


def loglike(y: np.ndarray, mu: np.ndarray, yerr: np.ndarray, sigma_int: float) -> float:
    var = np.clip(yerr**2 + sigma_int**2, 1e-12, None)
    return float(-0.5 * np.sum((y - mu) ** 2 / var + np.log(2 * np.pi * var)))


def design(model: str, x: np.ndarray, break_x: float | None = None, spline: SplineTransformer | None = None) -> np.ndarray:
    if model == "single":
        return np.column_stack([np.ones(len(x)), x])
    if model == "broken":
        if break_x is None:
            raise ValueError("break_x is required")
        return np.column_stack([np.ones(len(x)), x, np.maximum(0.0, x - break_x)])
    if model == "flexible":
        if spline is None:
            raise ValueError("spline is required")
        return np.column_stack([np.ones(len(x)), spline.transform(x[:, None])])
    raise ValueError(model)


def legacy_prediction(model: str, p: np.ndarray, x: np.ndarray) -> np.ndarray:
    """The submitted baseline parameterisation, expressed in log10(age/Myr)."""
    xm = x - CONV
    if model == "single":
        return p[0] + p[1] * xm
    xb = float(np.log10(np.exp(p[3])))
    return np.where(xm < xb, p[0] + p[1] * xm, p[0] + p[1] * xb + p[2] * (xm - xb))


def fit_linear_for_sigma(X: np.ndarray, y: np.ndarray, yerr: np.ndarray, sigma: float, ridge: float = 0.0) -> tuple[np.ndarray, float]:
    w = 1.0 / np.clip(yerr**2 + sigma**2, 1e-12, None)
    A = X.T @ (w[:, None] * X) + ridge * np.eye(X.shape[1])
    b = X.T @ (w * y)
    beta = np.linalg.pinv(A, rcond=1e-12) @ b
    return beta, loglike(y, X @ beta, yerr, sigma)


def profile_fit(model: str, x: np.ndarray, y: np.ndarray, yerr: np.ndarray, spline: SplineTransformer | None = None, sigma_fixed: float | None = None, ridge: float = 0.0) -> dict[str, float | np.ndarray]:
    # Preserve the submitted optimizer and parameterisation for the baseline
    # models.  This prevents an optimizer change from masquerading as an R1
    # scientific result.
    if model in {"single", "broken"}:
        if model == "single":
            mean0 = np.array([-1.5, -0.2])
            bounds_mean = [(-8.0, 8.0), (-5.0, 5.0)]
            if sigma_fixed is None:
                x0 = np.array([-1.5, -0.2, 0.5]); bounds = bounds_mean + [(1e-6, 5.0)]
            else:
                x0 = mean0; bounds = bounds_mean
        else:
            mean0 = np.array([-1.5, -0.2, -0.8, np.log(100.0)])
            bounds_mean = [(-8.0, 8.0), (-5.0, 5.0), (-5.0, 5.0), (np.log(20.0), np.log(1000.0))]
            if sigma_fixed is None:
                x0 = np.array([-1.5, -0.2, -0.8, np.log(100.0), 0.5]); bounds = bounds_mean + [(1e-6, 5.0)]
            else:
                x0 = mean0; bounds = bounds_mean
        def obj(p: np.ndarray) -> float:
            sig = float(p[-1]) if sigma_fixed is None else float(sigma_fixed)
            return -loglike(y, legacy_prediction(model, p, x), yerr, sig)
        opt = minimize(obj, x0=x0, bounds=bounds, method="L-BFGS-B", options={"maxiter": 40000})
        p = np.asarray(opt.x, float)
        sig = float(p[-1]) if sigma_fixed is None else float(sigma_fixed)
        mean_p = p[:-1] if sigma_fixed is None else p
        return {"beta": mean_p, "sigma_int": sig, "loglike": -float(opt.fun), "break_age_Myr": float(np.exp(mean_p[3])) if model == "broken" else np.nan}
    if model == "broken":
        grid = np.linspace(np.log10(20.0) + CONV, np.log10(1000.0) + CONV, 160)
        best = None
        for bx in grid:
            X = design(model, x, bx)
            fit = profile_linear(X, y, yerr, sigma_fixed, ridge)
            if best is None or fit["loglike"] > best["loglike"]:
                best = {**fit, "break_x": float(bx), "break_age_Myr": float(10 ** (bx - CONV))}
        assert best is not None
        return best
    X = design(model, x, spline=spline)
    fit = profile_linear(X, y, yerr, sigma_fixed, ridge)
    return {**fit, "break_x": np.nan, "break_age_Myr": np.nan}


def profile_linear(X: np.ndarray, y: np.ndarray, yerr: np.ndarray, sigma_fixed: float | None, ridge: float) -> dict[str, float | np.ndarray]:
    if sigma_fixed is not None:
        beta, ll = fit_linear_for_sigma(X, y, yerr, float(sigma_fixed), ridge)
        return {"beta": beta, "sigma_int": float(sigma_fixed), "loglike": ll}
    def objective(log_sigma: float) -> float:
        sig = float(np.exp(log_sigma))
        _, ll = fit_linear_for_sigma(X, y, yerr, sig, ridge)
        return -ll
    opt = minimize_scalar(objective, bounds=(np.log(1e-6), np.log(20.0)), method="bounded", options={"xatol": 1e-8})
    sigma = float(np.exp(opt.x))
    beta, ll = fit_linear_for_sigma(X, y, yerr, sigma, ridge)
    return {"beta": beta, "sigma_int": sigma, "loglike": ll}


def sigma_interval(model: str, x: np.ndarray, y: np.ndarray, yerr: np.ndarray, fit: dict[str, float | np.ndarray], spline: SplineTransformer | None, ridge: float) -> tuple[float, float]:
    target = float(fit["loglike"]) - 0.5
    def f(sig: float) -> float:
        z = profile_fit(model, x, y, yerr, spline=spline, sigma_fixed=sig, ridge=ridge)
        return float(z["loglike"]) - target
    grid = np.geomspace(1e-6, 20.0, 180)
    vals = np.array([f(s) for s in grid])
    roots = []
    for i in range(len(grid) - 1):
        if vals[i] == 0:
            roots.append(float(grid[i]))
        elif vals[i] * vals[i + 1] < 0:
            roots.append(float(brentq(f, float(grid[i]), float(grid[i + 1]))))
    if not roots:
        return np.nan, np.nan
    if len(roots) == 1:
        return roots[0], roots[0]
    return roots[0], roots[-1]


def model_row(name: str, d: pd.DataFrame, x: np.ndarray, y: np.ndarray, yerr: np.ndarray, spline: SplineTransformer | None, sigma_fixed: float | None = None, intervals: bool = True) -> tuple[dict[str, object], dict[str, object]]:
    ridge = 1.0 if name == "flexible" else 0.0
    fit = profile_fit(name, x, y, yerr, spline=spline, sigma_fixed=sigma_fixed, ridge=ridge)
    beta = np.asarray(fit["beta"], dtype=float)
    sigma = float(fit["sigma_int"])
    lo, hi = (np.nan, np.nan) if (sigma_fixed is not None or not intervals) else sigma_interval(name, x, y, yerr, fit, spline, ridge)
    k_mean = len(beta)
    k = k_mean + (0 if sigma_fixed is not None else 1)
    bic = k * np.log(len(y)) - 2 * float(fit["loglike"])
    row = {
        "model": name if sigma_fixed is None else f"{name}_sigma0",
        "N": len(y),
        "transform": "logit(f_L)",
        "age_error_mode": "catalogue_central_logAge50",
        "n_parameters": k,
        "log_likelihood": float(fit["loglike"]),
        "BIC": float(bic),
        "delta_BIC": np.nan,
        "sigma_int": sigma,
        "sigma_int_lower": lo,
        "sigma_int_upper": hi,
        "break_age_Myr": float(fit.get("break_age_Myr", np.nan)),
        "slope": float(beta[1]) if name == "single" else np.nan,
        "intercept": float(beta[0]) if name in {"single", "broken"} else np.nan,
        "notes": "fixed-regularization cubic spline specification check" if name == "flexible" else ("narrow deterministic sequence: sigma_int=0" if sigma_fixed is not None else "marginal intrinsic-scatter likelihood"),
    }
    return row, fit


def fit_all(d: pd.DataFrame, x: np.ndarray | None = None, transform: str = "logit", intervals: bool = True) -> tuple[pd.DataFrame, dict[str, dict[str, object]]]:
    x = d["x50"].to_numpy(float) if x is None else np.asarray(x, dtype=float)
    if transform == "logit":
        y = d["logit_f_L"].to_numpy(float)
        yerr = d["logit_f_L_err"].to_numpy(float)
    elif transform == "log":
        raw = d["f_L_raw"].to_numpy(float)
        y = np.log(raw)
        p16 = np.clip(d["f_L_p16"].to_numpy(float), 1e-12, None)
        p84 = np.clip(d["f_L_p84"].to_numpy(float), 1e-12, None)
        yerr = np.clip(0.5 * (np.log(p84) - np.log(p16)), 0.05, None)
    else:
        raise ValueError(transform)
    spline = SplineTransformer(n_knots=5, degree=3, include_bias=False, knots="quantile").fit(x[:, None])
    rows: list[dict[str, object]] = []
    fits: dict[str, dict[str, object]] = {}
    for name in ("single", "broken", "flexible"):
        row, fit = model_row(name, d, x, y, yerr, spline, intervals=intervals)
        row["transform"] = "logit(f_L)" if transform == "logit" else "log(f_L)"
        rows.append(row); fits[name] = fit
        row0, _ = model_row(name, d, x, y, yerr, spline, sigma_fixed=0.0)
        row0["transform"] = row["transform"]
        rows.append(row0)
    out = pd.DataFrame(rows)
    best = float(out.loc[~out["model"].str.endswith("_sigma0"), "BIC"].min())
    out["delta_BIC"] = out["BIC"] - best
    return out, fits


def age_mc(d: pd.DataFrame, n_draws: int, seed: int) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    x0 = d["x50"].to_numpy(float)
    sigx = d["age_log_sigma"].to_numpy(float)
    rows = []
    for draw in range(n_draws):
        x = x0 + rng.normal(0.0, sigx)
        tab, fits = fit_all(d, x=x, transform="logit", intervals=False)
        for _, r in tab.iterrows():
            if str(r["model"]).endswith("_sigma0"):
                continue
            rows.append({"draw": draw, "model": r["model"], "N": r["N"], "slope": r["slope"], "break_age_Myr": r["break_age_Myr"], "sigma_int": r["sigma_int"], "BIC": r["BIC"], "delta_BIC_broken_single": np.nan})
        # identify BIC differences within this draw
        sub = pd.DataFrame(rows[-3:])
        b = float(sub.loc[sub.model.eq("broken"), "BIC"].iloc[0] - sub.loc[sub.model.eq("single"), "BIC"].iloc[0])
        for rec in rows[-3:]: rec["delta_BIC_broken_single"] = b
    return pd.DataFrame(rows)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--population", type=Path, default=Path("outputs_v3/cluster_population.csv"))
    ap.add_argument("--unified", type=Path, default=Path("outputs_environment_regulation/unified_cluster_catalog.csv"))
    ap.add_argument("--outdir", type=Path, default=Path("results/r1"))
    ap.add_argument("--age-draws", type=int, default=200)
    ap.add_argument("--seed", type=int, default=20260917)
    args = ap.parse_args(); args.outdir.mkdir(parents=True, exist_ok=True)
    d = load_data(args.population, args.unified)
    tab, fits = fit_all(d, transform="logit")
    tab.to_csv(args.outdir / "age_width_model_comparison.csv", index=False)
    # A compact prediction table for the central flexible fit.
    xgrid = np.linspace(d.x50.min(), d.x50.max(), 200)
    spline = SplineTransformer(n_knots=5, degree=3, include_bias=False, knots="quantile").fit(d.x50.to_numpy(float)[:, None])
    f = fits["flexible"]
    Xg = design("flexible", xgrid, spline=spline)
    pd.DataFrame({"age_Myr": 10 ** (xgrid - CONV), "x_log10_age_yr": xgrid, "mu_logit_f_L": Xg @ np.asarray(f["beta"], float)}).to_csv(args.outdir / "flexible_age_predictions.csv", index=False)
    pd.DataFrame([{"model": "flexible", "N": len(d), "transform": "logit(f_L)", "regularization": "ridge_alpha_1", "n_knots": 5, "degree": 3, "sigma_int": f["sigma_int"], "sigma_int_lower": sigma_interval("flexible", d.x50.to_numpy(float), d.logit_f_L.to_numpy(float), d.logit_f_L_err.to_numpy(float), f, spline, 1.0)[0], "sigma_int_upper": sigma_interval("flexible", d.x50.to_numpy(float), d.logit_f_L.to_numpy(float), d.logit_f_L_err.to_numpy(float), f, spline, 1.0)[1], "predictive_score": "reported in r1_plots.py"}]).to_csv(args.outdir / "flexible_age_model.csv", index=False)
    mc = age_mc(d, args.age_draws, args.seed)
    summ = []
    for model, sub in mc.groupby("model"):
        for q in ["slope", "break_age_Myr", "sigma_int", "BIC", "delta_BIC_broken_single"]:
            a = sub[q].to_numpy(float); a = a[np.isfinite(a)]
            if len(a): summ.append({"dataset": "catalogue_age_MC", "model": model, "quantity": q, "N_draws": len(a), "p16": np.percentile(a, 16), "median": np.percentile(a, 50), "p84": np.percentile(a, 84)})
    central = tab[~tab.model.str.endswith("_sigma0")]
    for _, r in central.iterrows():
        for q in ["slope", "break_age_Myr", "sigma_int", "BIC", "delta_BIC"]:
            if np.isfinite(r[q]): summ.append({"dataset": "central_logAge50", "model": r["model"], "quantity": q, "N_draws": 1, "p16": r[q], "median": r[q], "p84": r[q]})
    pd.DataFrame(summ).to_csv(args.outdir / "age_uncertainty_sensitivity.csv", index=False)
    (args.outdir / "r1_age_inference_config.json").write_text(json.dumps({"seed": args.seed, "age_draws": args.age_draws, "spline_knots": 5, "spline_degree": 3, "ridge_alpha": 1.0, "population": str(args.population), "unified": str(args.unified)}, indent=2))
    print(f"N={len(d)}; wrote R1 age/width products to {args.outdir}")


if __name__ == "__main__":
    main()
