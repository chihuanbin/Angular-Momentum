#!/usr/bin/env python3
"""Pre-registered out-of-sample comparison of age and present-day descriptors."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import RepeatedKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler


NUMERIC_ENV = ["R_GC_kpc", "abs_Z_kpc", "orbital_eccentricity_proxy", "angular_momentum_z_kpc_kms", "orbital_energy_proxy_km2_s2", "zmax_proxy_kpc", "guiding_radius_kpc", "vertical_action_proxy_kpc_kms", "tidal_field_strength_proxy", "local_stellar_density_kpc3", "local_cluster_mass_density_Msun_kpc3"]
CATEGORICAL_ENV = ["disk_location", "vertical_environment", "orbital_family", "local_tidal_strength", "spiral_arm_association_optional", "bar_resonance_flag_proxy"]
STRUCTURAL = ["log_mass_Msun", "log_half_mass_radius_pc", "log_relaxation_time_Myr", "log_distance_kpc", "log_member_number"]


def prep_frame(catalog: Path) -> pd.DataFrame:
    d = pd.read_csv(catalog).copy()
    d["log_age_Myr"] = np.log10(d["age_Myr"].clip(lower=1e-3))
    d["log_mass_Msun"] = np.log10(d["mass_Msun"].clip(lower=1.0))
    d["log_half_mass_radius_pc"] = np.log10(d["half_mass_radius_pc"].clip(lower=0.05))
    d["log_relaxation_time_Myr"] = np.log10(d["relaxation_time_Myr"].clip(lower=0.01))
    d["log_distance_kpc"] = np.log10(d["distance_kpc"].clip(lower=0.01))
    d["log_member_number"] = np.log10(d["member_number"].clip(lower=1))
    d["target"] = d["angular_momentum_diversity_logit_fL"]
    needed = ["target", "log_age_Myr", *NUMERIC_ENV, *CATEGORICAL_ENV]
    ok = np.isfinite(d["target"].to_numpy(float)) & np.isfinite(d["log_age_Myr"].to_numpy(float))
    for c in NUMERIC_ENV: ok &= np.isfinite(d[c].to_numpy(float))
    return d.loc[ok].reset_index(drop=True)


def model(numeric: list[str], categorical: list[str]) -> Pipeline:
    num = Pipeline([("impute", SimpleImputer(strategy="median")), ("scale", StandardScaler())])
    cat = Pipeline([("impute", SimpleImputer(strategy="most_frequent")), ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False))])
    return Pipeline([("prep", ColumnTransformer([("num", num, numeric), ("cat", cat, categorical)])), ("ridge", Ridge(alpha=1.0))])


def evaluate(d: pd.DataFrame, numeric: list[str], categorical: list[str], cfg: dict) -> tuple[dict[str, object], pd.DataFrame]:
    y = d.target.to_numpy(float); X = d[numeric + categorical]
    cv = RepeatedKFold(n_splits=cfg["splits"], n_repeats=cfg["repeats"], random_state=cfg["seed"])
    pred = np.full((len(y), cfg["repeats"]), np.nan); fold_rows = []
    for fold, (train, test) in enumerate(cv.split(X)):
        rep = fold // cfg["splits"]
        fit = model(numeric, categorical).fit(X.iloc[train], y[train])
        p = fit.predict(X.iloc[test]); pred[test, rep] = p
        fold_rows.append({"fold": fold, "repeat": rep, "n_test": len(test), "rmse": np.sqrt(mean_squared_error(y[test], p)), "mae": mean_absolute_error(y[test], p), "r2": r2_score(y[test], p) if len(test)>1 else np.nan})
    pmean = np.nanmean(pred, axis=1)
    result = {"N": len(y), "n_splits": cfg["splits"], "n_repeats": cfg["repeats"], "ridge_alpha": 1.0, "rmse": float(np.sqrt(mean_squared_error(y, pmean))), "mae": float(mean_absolute_error(y, pmean)), "r2": float(r2_score(y, pmean)), "held_out_predictions": int(np.isfinite(pmean).sum())}
    return result, pd.DataFrame(fold_rows)


def feature_metadata(d: pd.DataFrame) -> pd.DataFrame:
    meanings = {"R_GC_kpc":"Galactocentric radius", "abs_Z_kpc":"absolute height above disk", "orbital_eccentricity_proxy":"orbital eccentricity proxy", "angular_momentum_z_kpc_kms":"Galactic orbital angular momentum", "orbital_energy_proxy_km2_s2":"orbital energy proxy", "zmax_proxy_kpc":"vertical orbital amplitude proxy", "guiding_radius_kpc":"guiding-centre radius", "vertical_action_proxy_kpc_kms":"vertical action proxy", "tidal_field_strength_proxy":"present-day tidal-field proxy", "local_stellar_density_kpc3":"local stellar-density proxy", "local_cluster_mass_density_Msun_kpc3":"local cluster mass density", "disk_location":"radial disk category", "vertical_environment":"vertical disk category", "orbital_family":"orbital-family category", "local_tidal_strength":"tidal-strength category", "spiral_arm_association_optional":"spiral-arm location proxy", "bar_resonance_flag_proxy":"bar-resonance proximity proxy", "log_age_Myr":"catalogue log age"}
    source = {c: "Hunt & Reffert catalogue or deterministic derived proxy" for c in [*NUMERIC_ENV, *CATEGORICAL_ENV, "log_age_Myr"]}
    rows=[]
    for c in ["log_age_Myr", *NUMERIC_ENV, *CATEGORICAL_ENV]:
        vals=d[c]; miss=float(vals.isna().mean()); rows.append({"feature":c,"physical/category meaning":meanings[c],"source":source[c],"scaling":"standardized within training fold" if c in NUMERIC_ENV or c=="log_age_Myr" else "one-hot within training fold","missingness":miss,"whether used in primary model":True})
    return pd.DataFrame(rows)


def main() -> None:
    ap=argparse.ArgumentParser(); ap.add_argument("--catalog",type=Path,default=Path("outputs_environment_regulation/unified_cluster_catalog.csv")); ap.add_argument("--outdir",type=Path,default=Path("results/r1")); ap.add_argument("--seed",type=int,default=20260708); ap.add_argument("--splits",type=int,default=5); ap.add_argument("--repeats",type=int,default=5); args=ap.parse_args(); args.outdir.mkdir(parents=True,exist_ok=True)
    d=prep_frame(args.catalog); cfg={"seed":args.seed,"splits":args.splits,"repeats":args.repeats}
    specs={"age_only":(["log_age_Myr"],[]),"environment_only":(NUMERIC_ENV,CATEGORICAL_ENV),"age_plus_environment":(["log_age_Myr",*NUMERIC_ENV],CATEGORICAL_ENV)}
    rows=[]; folds=[]
    for name,(num,cat) in specs.items():
        r,f=evaluate(d,num,cat,cfg); r["model"]=name; rows.append(r); f["model"]=name; folds.append(f)
    table=pd.DataFrame(rows); age_r=float(table.loc[table.model.eq("age_only"),"r2"].iloc[0]); table["delta_R2_vs_age_only"]=table.r2-age_r; table.to_csv(args.outdir/"environment_predictive_comparison.csv",index=False); pd.concat(folds,ignore_index=True).to_csv(args.outdir/"environment_cv_folds.csv",index=False)
    feature_metadata(d).to_csv(args.outdir/"environment_features.csv",index=False)
    (args.outdir/"r1_environment_config.json").write_text(json.dumps({"seed":args.seed,"splits":args.splits,"repeats":args.repeats,"algorithm":"Ridge(alpha=1.0) fixed for all three models","features":{"age":["log_age_Myr"],"environment_numeric":NUMERIC_ENV,"environment_categorical":CATEGORICAL_ENV}},indent=2))
    print(f"N={len(d)}; wrote fixed-fold age/environment comparison")


if __name__ == "__main__": main()
