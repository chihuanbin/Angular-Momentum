#!/usr/bin/env python3
"""Publication figures for the R1 inference architecture."""
from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from matplotlib.patches import FancyBboxPatch


def save(fig, out: Path, name: str) -> None:
    fig.savefig(out / f"{name}.pdf", bbox_inches="tight")
    fig.savefig(out / f"{name}.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def architecture(out: Path) -> None:
    fig, ax = plt.subplots(figsize=(8.6, 5.6)); ax.axis("off")
    def box(x,y,w,h,text,fc):
        p=FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0.018,rounding_size=0.018",fc=fc,ec="#263238",lw=.8,transform=ax.transAxes)
        ax.add_patch(p); ax.text(x+w/2,y+h/2,text,ha="center",va="center",fontsize=9,transform=ax.transAxes)
    def arrow(x1,y1,x2,y2): ax.annotate("",xy=(x2,y2),xytext=(x1,y1),xycoords=ax.transAxes,textcoords=ax.transAxes,arrowprops=dict(arrowstyle="-|>",lw=.8,color="#455a64"))
    box(.34,.88,.32,.075,"Gaia OC RV measurements","#e3f2fd")
    xs=[.05,.36,.67]; labels=["Mean relation\nsingle / broken / flexible","Residual width\nsigma_int = 0 versus >0","Added predictors\nage + environment"]
    for x,t in zip(xs,labels): box(x,.66,.28,.11,t,"#f5f5f5"); arrow(.50,.88,x+.14,.77)
    box(.30,.47,.40,.10,"Observational credibility","#fff3e0")
    for x in [.19,.50,.81]: arrow(x,.66,x if x==.50 else .50,.57)
    for x,t in zip([.04,.36,.68],["RV selection\nMonte Carlo","Synthetic mocks\nidentifiability","External RV\nLAMOST-led"]): box(x,.23,.28,.11,t,"#f5f5f5"); arrow(.50,.47,x+.14,.34)
    box(.30,.04,.40,.10,"Physical constraints\nwith explicit limitations","#e8f5e9")
    for x in [.18,.50,.82]: arrow(x,.23,.50,.14)
    ax.text(.02,.96,"Inference architecture",fontsize=11,weight="bold",transform=ax.transAxes)
    save(fig,out,"figure1_inference_architecture")


def age_relation(out: Path) -> None:
    d=pd.read_csv("outputs_v3/cluster_population.csv"); pred=pd.read_csv("results/r1/flexible_age_predictions.csv");
    fig,(ax,res)=plt.subplots(2,1,figsize=(7.0,6.2),sharex=True,gridspec_kw={"height_ratios":[2.3,1]},constrained_layout=True)
    x=np.log10(d.age_Myr); y=d.logit_f_L; e=d.logit_f_L_err
    ax.errorbar(x,y,yerr=e,fmt="o",ms=3.0,alpha=.55,color="#455a64",ecolor="#90a4ae",elinewidth=.5,label="Gaia clusters")
    p=pd.read_csv("results/r1/age_width_model_comparison.csv"); s=p[p.model.eq("single")].iloc[0];
    xg=np.linspace(x.min(),x.max(),250); mu=float(s.slope)*xg + float(s.intercept); ax.plot(xg,mu,color="#c62828",lw=1.5,label="single mean relation")
    ax.plot(np.log10(pred.age_Myr),pred.mu_logit_f_L,color="#1565c0",lw=1.3,label="fixed spline check")
    ax.set_ylabel(r"logit($f_{\rm L}$)"); ax.legend(frameon=False,fontsize=8,loc="upper left"); ax.set_title("Mean age dependence and residual population width",fontsize=10)
    # residuals from registered single relation
    yhat=float(s.slope)*x + float(s.intercept); res.axhline(0,color="0.3",lw=.7); res.scatter(x,y-yhat,s=9,color="#455a64",alpha=.6); res.set_ylabel("residual"); res.set_xlabel(r"log$_{10}$(age / Myr)")
    save(fig,out,"figure2_age_relation")


def robustness(out: Path) -> None:
    m=pd.read_csv("results/r1/age_width_model_comparison.csv")
    c=pd.read_csv("results/r1/constant_vs_age_model.csv")
    n=pd.read_csv("results/r1/narrow_sequence_bic_audit.csv")
    two=float(pd.read_csv("outputs_v3/model_comparison.csv").loc[lambda q: q.model.eq("two_phase"), "bic"].iloc[0])
    positive=[float(c.loc[c.model.eq("constant"), "BIC"].iloc[0]), float(m.loc[m.model.eq("single"), "BIC"].iloc[0]), float(m.loc[m.model.eq("broken"), "BIC"].iloc[0]), two, float(m.loc[m.model.eq("flexible"), "BIC"].iloc[0])]
    left=np.asarray(positive)-min(positive)
    baseline=float(n.loc[(n["dataset"].eq("baseline_status_ok")) & (n["transform"].eq("logit(f_L)")) & (n["model"].eq("single_sigma0")), "DeltaBIC_sigma0_minus_positive"].iloc[0])
    clean=float(n.loc[(n["dataset"].eq("clean_p_good_gt_0.7")) & (n["transform"].eq("logit(f_L)")) & (n["model"].eq("single_sigma_gt_0")), "DeltaBIC_sigma0_minus_positive"].iloc[0])
    log=float(n.loc[(n["dataset"].eq("baseline_status_ok")) & (n["transform"].eq("log(f_L)")) & (n["model"].eq("single_sigma0")), "DeltaBIC_sigma0_minus_positive"].iloc[0])
    fig,ax=plt.subplots(1,2,figsize=(7.3,3.45),constrained_layout=True)
    labels=["constant","single","broken","two-phase","flexible"]
    ax[0].bar(np.arange(5),left,color=["#90a4ae","#c62828","#ef9a9a","#bcaaa4","#1565c0"])
    ax[0].set_xticks(np.arange(5),labels,fontsize=7.5,rotation=20,ha="right")
    ax[0].set_ylabel(r"$\Delta$BIC among $\sigma_{int}>0$ models")
    ax[0].set_title("Mean-shape comparison")
    ax[0].text(0.02,0.96,"H$_{\\rm age}$ and H$_{\\rm shape}$",transform=ax[0].transAxes,va="top",fontsize=8)
    vals=[baseline,clean,log]
    ax[1].bar(np.arange(3),vals,color=["#9e9e9e","#607d8b","#8d6e63"])
    ax[1].set_yscale("log")
    ax[1].set_xticks(np.arange(3),["baseline\n$\\sigma_{int}=0$","clean\n$P(good)>0.7$","log transform"],fontsize=7.5)
    ax[1].set_ylabel(r"$\Delta$BIC against positive scatter (log scale)")
    ax[1].set_title("Width / transform robustness")
    for i,v in enumerate(vals): ax[1].text(i,v*1.12,f"{v:.1f}",ha="center",va="bottom",fontsize=7)
    save(fig,out,"figure3_model_robustness")


def synthetic_pair(out: Path) -> None:
    """Combine the frozen star-level and population-level panels."""
    a=mpimg.imread(out / "figure6_synthetic_recovery.png")
    b=mpimg.imread(out / "figure7_synthetic_population.png")
    fig,ax=plt.subplots(1,2,figsize=(7.4,3.7),constrained_layout=True)
    for axis,img,title,label in zip(ax,[a,b],["A  Star-level estimator calibration","B  Population-level synthetic identifiability"],["(a)","(b)"]):
        axis.imshow(img); axis.axis("off"); axis.set_title(title,fontsize=9,pad=4); axis.text(0.01,0.98,label,transform=axis.transAxes,ha="left",va="top",fontsize=9,weight="bold",color="white",bbox=dict(facecolor="black",alpha=.55,edgecolor="none",pad=2))
    save(fig,out,"figure6_7_synthetic_diagnostics")


def hierarchical(out: Path) -> None:
    d=pd.read_csv("outputs_hierarchical_bayes/latent_cluster_posteriors.csv"); fig,ax=plt.subplots(figsize=(6.8,4.2),constrained_layout=True); x=np.log10(d.age_Myr); ax.errorbar(x,d.theta_p50,yerr=[d.theta_p50-d.theta_p16,d.theta_p84-d.theta_p50],fmt="o",ms=3,alpha=.65,color="#1565c0",ecolor="#90caf9",elinewidth=.6); ax.scatter(x,d.observed_logit_f_L,s=8,color="#455a64",alpha=.35,label="observed"); ax.set_xlabel(r"log$_{10}$(age / Myr)"); ax.set_ylabel(r"latent logit($f_{\rm L}$)"); ax.set_title("Latent-cluster estimates and shrinkage",fontsize=10); ax.legend(frameon=False,fontsize=8); save(fig,out,"figure4_hierarchical_latent")


def external(out: Path) -> None:
    ext=pd.read_csv("outputs_independent_validation_sampling/external_cluster_validation.csv"); ext=ext[(ext["survey"]=="LAMOST")&ext["status"].eq("ok")].copy(); ext["y_ext"]=np.log(np.clip(ext["f_L"],1e-4,None)/np.clip(1-ext["f_L"],1e-4,None))
    dr=pd.read_csv("outputs_independent_validation_sampling/sampling_consistency_draws.csv.gz"); dr=dr[(dr["survey"]=="LAMOST")&(dr["mode"]=="selection_matched")]; q=dr.groupby("ID")["logit_f_L"].quantile([.025,.5,.975]).unstack(); q.columns=["lo","med","hi"]; z=ext.merge(q,left_on="ID",right_index=True)
    fig,ax=plt.subplots(figsize=(7.2,4.4),constrained_layout=True); x=np.log10(z.age_Myr); ax.vlines(x,z.lo,z.hi,color="#90a4ae",lw=1); ax.scatter(x,z.med,color="#90a4ae",s=16,label="Gaia matched 95% interval"); ax.scatter(x,z.y_ext,color="#c62828",s=18,label="LAMOST external value"); ax.set_xlabel(r"log$_{10}$(age / Myr)"); ax.set_ylabel(r"logit($f_{\rm L}$)"); ax.set_title("LAMOST sampling-matched external validation",fontsize=10); ax.legend(frameon=False,fontsize=8); save(fig,out,"figure8_lamost_validation")


def main() -> None:
    ap=argparse.ArgumentParser(); ap.add_argument("--outdir",type=Path,default=Path("revision/manuscript/figures")); args=ap.parse_args(); args.outdir.mkdir(parents=True,exist_ok=True); architecture(args.outdir); age_relation(args.outdir); robustness(args.outdir); synthetic_pair(args.outdir); hierarchical(args.outdir); external(args.outdir); print(f"Wrote R1 figures to {args.outdir}")


if __name__=="__main__": main()
