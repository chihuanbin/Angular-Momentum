#!/usr/bin/env python3
"""R1 constant-mean null versus the frozen simple age trend.

The likelihood, 125-cluster rows, logit transform, quoted measurement errors,
parameter bounds, optimizer, and intrinsic-scatter treatment reproduce the
registered single-trend implementation in ``analysis/r1_age_inference.py``.
The only changed component is the conditional-mean functional form.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import brentq, minimize
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import RepeatedKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler


CONV = np.log10(1.0e6)  # display log10(age/Myr) = internal log10(age/yr) - 6


def load_data(population: Path, unified: Path) -> pd.DataFrame:
    p = pd.read_csv(population)
    p = p[p["status"].eq("ok")].copy().sort_values("ID").reset_index(drop=True)
    u = pd.read_csv(unified)[["ID", "age_Myr_err_minus", "age_Myr_err_plus"]]
    d = p.merge(u, on="ID", how="left", validate="one_to_one")
    d = d[
        np.isfinite(d["age_Myr"])
        & (d["age_Myr"] > 0)
        & np.isfinite(d["logit_f_L"])
        & np.isfinite(d["logit_f_L_err"])
    ].copy()
    d["x_internal"] = np.log10(d["age_Myr"].to_numpy(float)) + CONV
    d["x_display"] = d["x_internal"] - CONV
    return d.reset_index(drop=True)


def load_cv_data(population: Path, unified: Path) -> pd.DataFrame:
    """Reconstruct the row order used by the registered environment CV."""
    p = pd.read_csv(population)[["ID", "logit_f_L"]]
    u = pd.read_csv(unified).copy()
    d = u.merge(p, on="ID", how="inner", validate="one_to_one")
    d["log_age_Myr"] = np.log10(d["age_Myr"].clip(lower=1.0e-3))
    d["x_display"] = d["log_age_Myr"]
    d = d[np.isfinite(d["logit_f_L"]) & np.isfinite(d["x_display"])].copy()
    # The pre-registered environment script requires every numeric descriptor
    # to be finite.  Keep that same eligibility gate and original row order.
    numeric_env = [
        "R_GC_kpc", "abs_Z_kpc", "orbital_eccentricity_proxy",
        "angular_momentum_z_kpc_kms", "orbital_energy_proxy_km2_s2",
        "zmax_proxy_kpc", "guiding_radius_kpc", "vertical_action_proxy_kpc_kms",
        "tidal_field_strength_proxy", "local_stellar_density_kpc3",
        "local_cluster_mass_density_Msun_kpc3",
    ]
    for col in numeric_env:
        d = d[np.isfinite(d[col])]
    return d.reset_index(drop=True)


def loglike(y: np.ndarray, mu: np.ndarray, yerr: np.ndarray, sigma_int: float) -> float:
    var = np.clip(yerr**2 + sigma_int**2, 1.0e-12, None)
    return float(-0.5 * np.sum((y - mu) ** 2 / var + np.log(2.0 * np.pi * var)))


def mean_prediction(model: str, p: np.ndarray, x_internal: np.ndarray) -> np.ndarray:
    if model == "constant":
        return np.full(len(x_internal), float(p[0]))
    if model == "age":
        # Keep the submitted parameterisation: intercept is at log10(age/Myr).
        return float(p[0]) + float(p[1]) * (x_internal - CONV)
    raise ValueError(model)


def fit_model(model: str, x: np.ndarray, y: np.ndarray, yerr: np.ndarray) -> dict[str, object]:
    if model == "constant":
        x0 = np.array([-1.5, 0.5])
        bounds = [(-8.0, 8.0), (1.0e-6, 5.0)]
    elif model == "age":
        x0 = np.array([-1.5, -0.2, 0.5])
        bounds = [(-8.0, 8.0), (-5.0, 5.0), (1.0e-6, 5.0)]
    else:
        raise ValueError(model)

    def objective(p: np.ndarray) -> float:
        if model == "constant":
            mu = mean_prediction(model, p, x)
            sigma = float(p[1])
        else:
            mu = mean_prediction(model, p, x)
            sigma = float(p[2])
        return -loglike(y, mu, yerr, sigma)

    opt = minimize(objective, x0=x0, bounds=bounds, method="L-BFGS-B", options={"maxiter": 40000})
    p = np.asarray(opt.x, dtype=float)
    ll = -float(opt.fun)
    if model == "constant":
        intercept, slope, sigma = float(p[0]), np.nan, float(p[1])
        k = 2
    else:
        intercept, slope, sigma = float(p[0]), float(p[1]), float(p[2])
        k = 3
    bic = k * np.log(len(y)) - 2.0 * ll
    return {
        "model": model,
        "params": p,
        "intercept": intercept,
        "slope": slope,
        "sigma_int": sigma,
        "logL_max": ll,
        "BIC": float(bic),
        "optimizer_success": bool(opt.success),
        "optimizer_message": str(opt.message),
    }


def profile_slope_interval(x: np.ndarray, y: np.ndarray, yerr: np.ndarray, fit: dict[str, object]) -> tuple[float, float]:
    """68% profile-likelihood interval for the age slope."""
    pbest = np.asarray(fit["params"], dtype=float)
    target = float(fit["logL_max"]) - 0.5

    def profile(slope: float) -> float:
        def objective(q: np.ndarray) -> float:
            p = np.array([q[0], slope, q[1]], dtype=float)
            return -loglike(y, mean_prediction("age", p, x), yerr, float(q[1]))

        opt = minimize(
            objective,
            x0=np.array([pbest[0], pbest[2]], dtype=float),
            bounds=[(-8.0, 8.0), (1.0e-6, 5.0)],
            method="L-BFGS-B",
            options={"maxiter": 40000},
        )
        return -float(opt.fun)

    slope_best = float(pbest[1])
    grid = np.linspace(-5.0, 5.0, 401)
    vals = np.array([profile(float(s)) - target for s in grid])
    roots: list[float] = []
    for i in range(len(grid) - 1):
        if vals[i] == 0.0:
            roots.append(float(grid[i]))
        elif vals[i] * vals[i + 1] < 0.0:
            roots.append(float(brentq(lambda s: profile(float(s)) - target, float(grid[i]), float(grid[i + 1]))))
    lower = max(-5.0, min(roots) if roots else np.nan)
    upper = min(5.0, max(roots) if roots else np.nan)
    if not roots:
        return np.nan, np.nan
    # The optimum is inside the interval by construction for this fit.
    return float(lower), float(upper)


def repeated_cv(d: pd.DataFrame, seed: int, splits: int, repeats: int) -> pd.DataFrame:
    """Use the registered 5x5 RepeatedKFold geometry and target values."""
    y = d["logit_f_L"].to_numpy(float)
    x = d["x_display"].to_numpy(float).reshape(-1, 1)
    cv = RepeatedKFold(n_splits=splits, n_repeats=repeats, random_state=seed)
    pred = {"constant": np.full((len(y), repeats), np.nan), "age": np.full((len(y), repeats), np.nan)}
    fold_rows: list[dict[str, object]] = []
    for fold, (train, test) in enumerate(cv.split(x)):
        rep = fold // splits
        mean_train = float(np.mean(y[train]))
        pred["constant"][test, rep] = mean_train
        age_fit = Pipeline([("scale", StandardScaler()), ("ridge", Ridge(alpha=1.0))])
        age_fit.fit(x[train], y[train])
        pred["age"][test, rep] = age_fit.predict(x[test])
        for model in ("constant", "age"):
            p = pred[model][test, rep]
            fold_rows.append(
                {
                    "model": model,
                    "fold": fold,
                    "repeat": rep,
                    "n_test": len(test),
                    "rmse": float(np.sqrt(mean_squared_error(y[test], p))),
                    "r2": float(r2_score(y[test], p)),
                }
            )
    rows: list[dict[str, object]] = []
    for model in ("constant", "age"):
        pmean = np.nanmean(pred[model], axis=1)
        rows.append(
            {
                "model": model,
                "N": len(y),
                "folds": f"RepeatedKFold(n_splits={splits}, n_repeats={repeats}, random_state={seed})",
                "held_out_RMSE": float(np.sqrt(mean_squared_error(y, pmean))),
                "held_out_R2": float(r2_score(y, pmean)),
                "held_out_MAE": float(np.mean(np.abs(y - pmean))),
                "delta_RMSE_vs_constant": np.nan,
                "delta_R2_vs_constant": np.nan,
                "notes": "constant training mean; age is the registered standardized Ridge(alpha=1) age-only predictor",
            }
        )
    out = pd.DataFrame(rows)
    c = out.loc[out.model.eq("constant")].iloc[0]
    out.loc[out.model.eq("age"), "delta_RMSE_vs_constant"] = float(out.loc[out.model.eq("age"), "held_out_RMSE"].iloc[0] - c.held_out_RMSE)
    out.loc[out.model.eq("age"), "delta_R2_vs_constant"] = float(out.loc[out.model.eq("age"), "held_out_R2"].iloc[0] - c.held_out_R2)
    out.loc[out.model.eq("constant"), "delta_RMSE_vs_constant"] = 0.0
    out.loc[out.model.eq("constant"), "delta_R2_vs_constant"] = 0.0
    return out, pd.DataFrame(fold_rows)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--population", type=Path, default=Path("outputs_v3/cluster_population.csv"))
    ap.add_argument("--unified", type=Path, default=Path("outputs_environment_regulation/unified_cluster_catalog.csv"))
    ap.add_argument("--outdir", type=Path, default=Path("results/r1"))
    ap.add_argument("--seed", type=int, default=20260708)
    ap.add_argument("--splits", type=int, default=5)
    ap.add_argument("--repeats", type=int, default=5)
    args = ap.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    d = load_data(args.population, args.unified)
    cv_d = load_cv_data(args.population, args.unified)
    y = d["logit_f_L"].to_numpy(float)
    yerr = d["logit_f_L_err"].to_numpy(float)
    x = d["x_internal"].to_numpy(float)
    fits = {m: fit_model(m, x, y, yerr) for m in ("constant", "age")}
    slope_lo, slope_hi = profile_slope_interval(x, y, yerr, fits["age"])
    age = fits["age"]
    constant = fits["constant"]
    bic_delta = float(constant["BIC"] - age["BIC"])
    rows = [
        {
            "model": "constant",
            "N": len(d),
            "k": 2,
            "intercept": constant["intercept"],
            "slope": np.nan,
            "slope_error_or_interval": "not applicable",
            "sigma_int": constant["sigma_int"],
            "logL_max": constant["logL_max"],
            "BIC": constant["BIC"],
            "delta_BIC_vs_constant": 0.0,
            "notes": "M0: mu(x)=c; x internally log10(age/yr), but constant is unit-invariant; sigma_int fitted with registered L-BFGS-B likelihood",
        },
        {
            "model": "age",
            "N": len(d),
            "k": 3,
            "intercept": age["intercept"],
            "slope": age["slope"],
            "slope_error_or_interval": f"profile 68% interval [{slope_lo:.9f}, {slope_hi:.9f}]",
            "sigma_int": age["sigma_int"],
            "logL_max": age["logL_max"],
            "BIC": age["BIC"],
            "delta_BIC_vs_constant": -bic_delta,
            "notes": "M1: mu(x)=a+b log10(age/Myr); same rows, y, sigma_y, clipping, likelihood and optimizer as frozen single trend",
        },
    ]
    pd.DataFrame(rows).to_csv(args.outdir / "constant_vs_age_model.csv", index=False)
    cv, folds = repeated_cv(cv_d, args.seed, args.splits, args.repeats)
    cv.to_csv(args.outdir / "constant_vs_age_cv.csv", index=False)
    folds.to_csv(args.outdir / "constant_vs_age_cv_folds.csv", index=False)
    age_summary = pd.DataFrame(
        [
            {
                "N": len(d),
                "slope_b": age["slope"],
                "slope_interval_lower": slope_lo,
                "slope_interval_upper": slope_hi,
                "slope_interval_type": "profile likelihood 68% (Delta logL=0.5)",
                "interval_includes_zero": bool(slope_lo <= 0.0 <= slope_hi),
                "age_logL_max": age["logL_max"],
                "constant_logL_max": constant["logL_max"],
                "age_BIC": age["BIC"],
                "constant_BIC": constant["BIC"],
                "delta_BIC_constant_minus_age": bic_delta,
                "age_sigma_int": age["sigma_int"],
                "constant_sigma_int": constant["sigma_int"],
                "age_intercept_at_log10_age_Myr": age["intercept"],
                "constant_intercept": constant["intercept"],
                "notes": "positive slope and interval excludes zero; internal x=log10(age/yr), display/parameter intercept uses log10(age/Myr)",
            }
        ]
    )
    age_summary.to_csv(args.outdir / "age_slope_summary.csv", index=False)
    (args.outdir / "r1_constant_age_null_config.json").write_text(
        json.dumps(
            {
                "population": str(args.population),
                "unified": str(args.unified),
                "N": len(d),
                "transform": "logit(f_L)",
                "optimizer": "L-BFGS-B, maxiter=40000",
                "sigma_int_bounds": [1.0e-6, 5.0],
                "cv": {"seed": args.seed, "splits": args.splits, "repeats": args.repeats},
            },
            indent=2,
        )
    )
    print(f"N={len(d)}")
    print(pd.DataFrame(rows)[["model", "N", "logL_max", "BIC", "delta_BIC_vs_constant", "sigma_int"]].to_string(index=False))
    print(cv[["model", "held_out_RMSE", "held_out_R2", "delta_RMSE_vs_constant", "delta_R2_vs_constant"]].to_string(index=False))
    print(f"age slope={age['slope']:.9f}; profile 68% interval=[{slope_lo:.9f}, {slope_hi:.9f}]")


if __name__ == "__main__":
    main()
