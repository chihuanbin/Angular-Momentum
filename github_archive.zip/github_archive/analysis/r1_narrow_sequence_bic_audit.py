#!/usr/bin/env python3
"""Independent audit of the sigma_int=0 narrow-sequence comparison.

This deliberately does not import the population-fitting implementation.  It
re-reads the frozen population table, reconstructs the two transforms, fits
the single age mean with the same Gaussian likelihood, and recomputes BIC
from log-likelihood contributions.
"""
from __future__ import annotations

import hashlib
import math
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import minimize, minimize_scalar

ROOT = Path(__file__).resolve().parents[1]
POP = ROOT / "outputs_v3/cluster_population.csv"
OUT = ROOT / "results/r1"
CONV = math.log10(1.0e6)


def ll(y: np.ndarray, x: np.ndarray, err: np.ndarray, p: np.ndarray, fixed_sigma: float | None) -> tuple[float, np.ndarray, np.ndarray]:
    mu = p[0] + p[1] * (x - CONV)
    sig = float(p[2]) if fixed_sigma is None else float(fixed_sigma)
    var = err * err + sig * sig
    contrib = -0.5 * ((y - mu) ** 2 / var + np.log(2.0 * np.pi * var))
    return float(np.sum(contrib)), mu, contrib


def fit(y: np.ndarray, x: np.ndarray, err: np.ndarray, fixed_sigma: float | None) -> tuple[np.ndarray, float, np.ndarray, np.ndarray]:
    if fixed_sigma is None:
        fun = lambda p: -ll(y, x, err, p, None)[0]
        opt = minimize(fun, np.array([-1.5, -0.2, 0.5]), method="L-BFGS-B",
                       bounds=[(-8.0, 8.0), (-5.0, 5.0), (1.0e-6, 5.0)],
                       options={"maxiter": 40000})
        p = np.asarray(opt.x, float)
    else:
        fun = lambda p: -ll(y, x, err, p, fixed_sigma)[0]
        opt = minimize(fun, np.array([-1.5, -0.2]), method="L-BFGS-B",
                       bounds=[(-8.0, 8.0), (-5.0, 5.0)],
                       options={"maxiter": 40000})
        p = np.asarray(opt.x, float)
    logl, mu, contrib = ll(y, x, err, p, fixed_sigma)
    return p, logl, mu, contrib


def canonical_hash(d: pd.DataFrame) -> tuple[str, str]:
    cols = ["ID", "Name", "age_Myr", "y", "sigma_y"]
    payload = d[cols].to_csv(index=False, float_format="%.17g", lineterminator="\n").encode()
    row_hash = hashlib.sha256(payload).hexdigest()
    id_payload = d[["ID", "Name"]].to_csv(index=False, lineterminator="\n").encode()
    return row_hash, hashlib.sha256(id_payload).hexdigest()


def make_data(transform: str, clean: bool) -> pd.DataFrame:
    p = pd.read_csv(POP)
    p = p[p.status.eq("ok")].copy()
    if clean:
        p = p[p.p_good_v3 > 0.7].copy()
    p = p.sort_values("ID")
    p["x"] = np.log10(p.age_Myr.to_numpy(float)) + CONV
    if transform == "logit":
        p["y"] = p.logit_f_L
        p["sigma_y"] = p.logit_f_L_err
    elif transform == "log":
        p = p[p.f_L_raw > 0].copy()
        p["y"] = np.log(p.f_L_raw)
        p["sigma_y"] = np.maximum(0.05, 0.5 * (np.log(np.maximum(p.f_L_p84, 1e-12)) - np.log(np.maximum(p.f_L_p16, 1e-12))))
    else:
        raise ValueError(transform)
    p = p[np.isfinite(p.x) & np.isfinite(p.y) & np.isfinite(p.sigma_y) & (p.sigma_y > 0)].copy()
    p["age"] = p.age_Myr
    return p.reset_index(drop=True)


def one_result(d: pd.DataFrame, transform: str, clean: bool, fixed_sigma: float | None) -> dict[str, object]:
    p, logl, mu, contrib = fit(d.y.to_numpy(float), d.x.to_numpy(float), d.sigma_y.to_numpy(float), fixed_sigma)
    k = 2 if fixed_sigma is not None else 3
    n = len(d)
    bic = k * np.log(n) - 2.0 * logl
    rh, ih = canonical_hash(d)
    return {"dataset": "clean_p_good_gt_0.7" if clean else "baseline_status_ok",
            "transform": "logit(f_L)" if transform == "logit" else "log(f_L)",
            "model": "single_sigma0" if fixed_sigma is not None else "single_sigma_gt_0",
            "N": n, "k": k, "logL_max": logl, "k_ln_N": k * np.log(n),
            "minus_2_logL": -2.0 * logl, "BIC": bic,
            "DeltaBIC_sigma0_minus_positive": np.nan,
            "sigma_int": 0.0 if fixed_sigma is not None else float(p[2]),
            "row_hash": rh, "id_hash": ih,
            "optimizer_success": True,
            "notes": "independent single-mean Gaussian likelihood; same rows/hash across paired fits"}


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    rows: list[dict[str, object]] = []
    residual_rows: list[dict[str, object]] = []
    for clean in (False, True):
        for transform in ("logit", "log"):
            d = make_data(transform, clean)
            pos = one_result(d, transform, clean, None)
            zero = one_result(d, transform, clean, 0.0)
            delta = float(zero["BIC"] - pos["BIC"])
            pos["DeltaBIC_sigma0_minus_positive"] = delta
            zero["DeltaBIC_sigma0_minus_positive"] = delta
            rows.extend([pos, zero])
            if not clean and transform == "logit":
                p, logl, mu, contrib = fit(d.y.to_numpy(float), d.x.to_numpy(float), d.sigma_y.to_numpy(float), 0.0)
                resid = d.y.to_numpy(float) - mu
                for j, (_, r) in enumerate(d.iterrows()):
                    residual_rows.append({"cluster": r.Name, "ID": int(r.ID), "age": float(r.age),
                                          "y": float(r.y), "sigma_y": float(r.sigma_y), "mu_model": float(mu[j]),
                                          "residual": float(resid[j]), "standardized_residual": float(resid[j] / r.sigma_y),
                                          "loglike_contribution": float(contrib[j])})
    out = pd.DataFrame(rows)
    # Human-facing aliases mirror the audit specification while retaining
    # identifier-safe column names for downstream scripts.
    out["k*ln(N)"] = out["k_ln_N"]
    out["-2logL"] = out["minus_2_logL"]
    out["DeltaBIC"] = out["DeltaBIC_sigma0_minus_positive"]
    out.to_csv(OUT / "narrow_sequence_bic_audit.csv", index=False)
    pd.DataFrame(residual_rows).to_csv(OUT / "narrow_sequence_residuals.csv", index=False)
    print(out[["dataset", "transform", "model", "N", "k", "logL_max", "BIC", "DeltaBIC_sigma0_minus_positive"]].to_string(index=False))


if __name__ == "__main__":
    main()
