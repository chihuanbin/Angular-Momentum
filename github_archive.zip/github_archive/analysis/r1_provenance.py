"""Write a machine-readable provenance manifest for the R1 products."""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def entry(script: str, inputs: list[str], outputs: list[str], config: str | None,
          seed: int | None, sample_size: int | None, notes: str) -> dict:
    files = inputs + outputs + ([config] if config else [])
    return {
        "script": script,
        "script_sha256": sha256(ROOT / script),
        "inputs": [{"path": p, "sha256": sha256(ROOT / p)} for p in inputs],
        "outputs": [{"path": p, "sha256": sha256(ROOT / p)} for p in outputs],
        "configuration": {"path": config, "sha256": sha256(ROOT / config)} if config else None,
        "random_seed": seed,
        "sample_size": sample_size,
        "notes": notes,
    }


manifest = {
    "project": "Gaia DR3 Constraints on Angular-Momentum Diversity in Galactic Open Clusters",
    "revision": "A&A R1",
    "generated_utc": datetime.now(timezone.utc).isoformat(),
    "git_commit": None,
    "git_note": "No Git repository is present in the supplied workspace.",
    "entries": [
        entry("analysis/r1_age_inference.py",
              ["outputs_v3/cluster_population.csv", "outputs_environment_regulation/unified_cluster_catalog.csv"],
              ["results/r1/age_width_model_comparison.csv", "results/r1/flexible_age_model.csv",
               "results/r1/flexible_age_predictions.csv", "results/r1/age_uncertainty_sensitivity.csv"],
              "results/r1/r1_age_inference_config.json", 20260917, 125,
              "200 latent log-age draws; submitted optimizer and parameterisation retained."),
        entry("analysis/r1_transform_robustness.py",
              ["outputs_v3/cluster_population.csv"],
              ["results/r1/transform_robustness.csv", "results/r1/fl_boundary_cases.csv"],
              "results/r1/r1_transform_config.json", None, 125,
              "Registered logit clip compared with log of all positive raw f_L."),
        entry("analysis/r1_narrow_sequence_bic_audit.py",
              ["outputs_v3/cluster_population.csv"],
              ["results/r1/narrow_sequence_bic_audit.csv", "results/r1/narrow_sequence_residuals.csv",
               "revision/audit/NARROW_SEQUENCE_BIC_AUDIT.md"],
              None, None, 125,
              "Independent Gaussian-likelihood/BIC audit; paired fits share row and ID hashes."),
        entry("analysis/r1_constant_age_null.py",
              ["outputs_v3/cluster_population.csv", "outputs_environment_regulation/unified_cluster_catalog.csv"],
              ["results/r1/constant_vs_age_model.csv", "results/r1/constant_vs_age_cv.csv",
               "results/r1/constant_vs_age_cv_folds.csv", "results/r1/age_slope_summary.csv"],
              "results/r1/r1_constant_age_null_config.json", 20260708, 125,
              "Constant/no-age null and frozen simple age trend; CV uses the existing repeated five-fold geometry."),
        entry("analysis/r1_claim_preservation_ledger.py",
              ["results/r1/age_width_model_comparison.csv", "results/r1/environment_predictive_comparison.csv",
               "results/r1/selection_scatter_summary.csv", "results/r1/synthetic_identifiability.csv",
               "results/r1/narrow_sequence_bic_audit.csv",
               "outputs_independent_validation_sampling/sampling_consistency_result_table.csv"],
              ["revision/audit/R1_CLAIM_PRESERVATION_LEDGER.csv"], None, None, 125,
              "Closure-pass ledger preserving strongest supported statistical/model-conditional claims."),
        entry("analysis/r1_number_traceability.py",
              ["results/r1/age_width_model_comparison.csv", "results/r1/flexible_age_model.csv",
               "results/r1/age_uncertainty_sensitivity.csv", "results/r1/transform_robustness.csv",
               "results/r1/environment_predictive_comparison.csv", "results/r1/selection_scatter_summary.csv",
               "results/r1/synthetic_identifiability.csv", "results/r1/narrow_sequence_bic_audit.csv",
               "outputs_v3/cluster_population.csv",
               "outputs_independent_validation_sampling/sampling_consistency_result_table.csv"],
              ["revision/audit/R1_NUMBER_TRACEABILITY.csv"], None, None, 125,
              "All main-text numerical claims map to source CSV columns and scripts."),
        entry("analysis/r1_claim_audit.py",
              ["revision/manuscript/main.tex", "revision/response_to_referee.md"],
              ["revision/audit/R1_CLAIM_AUDIT.md"], None, None, None,
              "Case-insensitive claim-term scan with explicit unqualified physical/causal overclaim check."),
        entry("analysis/r1_environment_prediction.py",
              ["outputs_environment_regulation/unified_cluster_catalog.csv"],
              ["results/r1/environment_predictive_comparison.csv", "results/r1/environment_cv_folds.csv",
               "results/r1/environment_features.csv"],
              "results/r1/r1_environment_config.json", 20260708, 125,
              "Fixed Ridge alpha=1; identical five-fold, five-repeat splits."),
        entry("analysis/r1_selection_summary.py",
              ["outputs_selection_function_mc/selection_mc_summary.csv", "outputs_v3/cluster_population.csv"],
              ["results/r1/selection_scatter_summary.csv"],
              None, None, 125,
              "Existing selection Monte Carlo summarised without changing retention fractions."),
        entry("analysis/r1_synthetic_identifiability.py",
              ["outputs_v3/cluster_population.csv", "revision/freeze/R1_SYNTHETIC_SCENARIOS.yaml"],
              ["results/r1/synthetic_identifiability.csv"],
              "revision/freeze/R1_SYNTHETIC_SCENARIOS.yaml", 20260917, 250,
              "Frozen S0-S3 scenarios; 250 population replicates per scenario/completeness cell."),
        entry("analysis/r1_synthetic_recovery_audit.py",
              ["outputs_synthetic_cluster_recovery/recovery_statistics.csv",
              "outputs_synthetic_cluster_recovery/synthetic_cluster_recovery_design.csv"],
              ["results/r1/synthetic_recovery_calibration.csv", "revision/audit/SYNTHETIC_RECOVERY_AUDIT.md"],
              None, None, 715,
              "Audits the existing star-level result and adds normalized calibration quantities."),
        entry("analysis/r1_plots.py",
              ["results/r1/age_width_model_comparison.csv", "results/r1/age_uncertainty_sensitivity.csv",
               "results/r1/transform_robustness.csv", "results/r1/selection_scatter_summary.csv",
               "results/r1/synthetic_recovery_calibration.csv", "results/r1/constant_vs_age_model.csv",
               "results/r1/narrow_sequence_bic_audit.csv", "external_rv_data/provenance.json"],
              ["revision/manuscript/figures/figure1_inference_architecture.pdf",
               "revision/manuscript/figures/figure2_age_relation.pdf",
               "revision/manuscript/figures/figure3_model_robustness.pdf",
               "revision/manuscript/figures/figure6_7_synthetic_diagnostics.pdf",
               "revision/manuscript/figures/figure4_hierarchical_latent.pdf",
               "revision/manuscript/figures/figure8_lamost_validation.pdf"],
              None, None, 125, "Vector figures regenerated from frozen machine-readable outputs."),
        {
            "script": "latexmk -pdf -interaction=nonstopmode -halt-on-error revision/manuscript/main.tex",
            "script_sha256": None,
            "inputs": [{"path": "revision/manuscript/main.tex", "sha256": sha256(ROOT / "revision/manuscript/main.tex")},
                       {"path": "revision/manuscript/ref_clean.bib", "sha256": sha256(ROOT / "revision/manuscript/ref_clean.bib")}],
            "outputs": [{"path": "revision/manuscript/main.pdf", "sha256": sha256(ROOT / "revision/manuscript/main.pdf")}],
            "configuration": None,
            "random_seed": None,
            "sample_size": 125,
            "notes": "Clean-state A&A compilation; no fatal errors, undefined references, or overfull boxes in final log.",
        },
        entry("analysis/r1_final_audit.py", ["revision/manuscript/main.tex", "revision/manuscript/main.log"],
              ["revision/audit/R1_FINAL_AUDIT.md"], None, None, 125,
              "Automated numerical, claim, transform, sample, reference, figure, table, and LaTeX checks."),
    ],
}

out = ROOT / "provenance/r1_provenance.json"
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
print(out)
