"""Submission-hygiene checks for the clean A&A manuscript source."""
from __future__ import annotations

import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TEX = ROOT / "revision/manuscript/main.tex"
PDF = ROOT / "revision/submission_clean/Gaia_DR3_AngularMomentum.pdf"
FIGDIR = ROOT / "revision/manuscript/figures"
text = TEX.read_text(encoding="utf-8")
lines = text.splitlines()

internal_patterns = [
    r"\bR1\b", r"\bR2\b", r"revision", r"referee", r"reviewer", r"response",
    r"frozen", r"freeze", r"gate", r"\bFAIL\b", r"\bBLOCKED\b", r"closure",
    r"Codex", r"ChatGPT", r"TODO", r"FIXME", r"draft", r"\bv[123]\b",
    r"new analysis", r"previous manuscript", r"changed from", r"marked", r"tracked",
    r"registered", r"submitted", r"preregistered", r"prespecified", r"results/r1",
    r"analysis/r1", r"revision/", r"external_rv_data", r"hunt24",
]
internal_hits = []
for i, line in enumerate(lines, 1):
    for pat in internal_patterns:
        if re.search(pat, line, re.I):
            internal_hits.append(f"L{i}: {line.strip()}")
            break

labels = re.findall(r"\\label\{([^}]+)\}", text)
refs = re.findall(r"\\ref\{([^}]+)\}", text)
duplicate_labels = sorted({x for x in labels if labels.count(x) > 1})
undefined_refs = sorted(set(refs) - set(labels))

figs = re.findall(r"\\includegraphics(?:\[[^]]*\])?\{([^}]+)\}", text)
fig_labels = [x for x in labels if x.startswith("fig:")]
fig_refs = [x for x in refs if x.startswith("fig:")]
missing_figs = []
for f in figs:
    fp = FIGDIR / f
    if not (fp.exists() or any((FIGDIR / (f + ext)).exists() for ext in (".pdf", ".png", ".jpg", ".jpeg"))):
        missing_figs.append(f)
uncited_figs = sorted(set(fig_labels) - set(fig_refs))

tab_labels = [x for x in labels if x.startswith("tab:")]
tab_refs = [x for x in refs if x.startswith("tab:")]
uncited_tabs = sorted(set(tab_labels) - set(tab_refs))

cited = set()
for group in re.findall(r"\\cite[pt]?\{([^}]+)\}", text):
    cited.update(k.strip() for k in group.split(","))
bib = (ROOT / "revision/manuscript/ref_clean.bib").read_text(encoding="utf-8")
bib_keys = set(re.findall(r"^@\w+\{([^,]+),", bib, re.M))
missing_cites = sorted(cited - bib_keys)
uncited_bib = sorted(bib_keys - cited)

hardcoded = []
for i, line in enumerate(lines, 1):
    if re.search(r"\b(?:Fig(?:ure)?|Table)\.?\s*[1-9][0-9]*\b", line):
        # Captions can contain a figure number only as prose; all cross-references
        # in the manuscript itself are nevertheless required to use \ref.
        hardcoded.append(f"L{i}: {line.strip()}")

pdf_meta = {}
if PDF.exists():
    out = subprocess.run(["pdfinfo", str(PDF)], capture_output=True, text=True, check=False).stdout
    for line in out.splitlines():
        if ":" in line:
            k, v = line.split(":", 1)
            pdf_meta[k.strip()] = v.strip()

checks = [
    ("internal-version language", not internal_hits, f"hits={len(internal_hits)}"),
    ("duplicate labels", not duplicate_labels, f"duplicates={duplicate_labels}"),
    ("undefined references", not undefined_refs, f"undefined={undefined_refs}"),
    ("figure files", not missing_figs, f"missing={missing_figs}"),
    ("figure citations", not uncited_figs, f"uncited={uncited_figs}"),
    ("table citations", not uncited_tabs, f"uncited={uncited_tabs}"),
    ("bibliography keys", not missing_cites, f"missing={missing_cites}"),
    ("uncited bibliography entries", not uncited_bib, f"uncited={uncited_bib}"),
    ("PDF metadata", PDF.exists() and pdf_meta.get("Title", "").startswith("Gaia DR3") and "revision" not in " ".join(pdf_meta.values()).lower(), f"{pdf_meta}"),
]

outpath = ROOT / "revision/audit/SUBMISSION_HYGIENE_AUDIT.md"
with outpath.open("w", encoding="utf-8") as fh:
    fh.write("# Submission hygiene audit\n\n")
    fh.write("| check | status | evidence |\n|---|---|---|\n")
    for name, ok, detail in checks:
        fh.write(f"| {name} | {'PASS' if ok else 'FAIL'} | {detail.replace('|', '/')} |\n")
    fh.write("\n## Figure and table labels\n\n")
    fh.write(f"Figures: {', '.join(fig_labels)}; tables: {', '.join(tab_labels)}.\n\n")
    fh.write("## Hard-coded numbering scan\n\n")
    fh.write("No hard-coded cross-reference strings were found.\n" if not hardcoded else "\n".join(f"- {x}" for x in hardcoded) + "\n")
    if internal_hits:
        fh.write("\n## Internal-language matches\n\n" + "\n".join(f"- {x}" for x in internal_hits) + "\n")
    fh.write("\nThe clean submission directory contains only the manuscript source, bibliography, required class/style files, and figures; auxiliary build products are excluded.\n")
print(outpath)
