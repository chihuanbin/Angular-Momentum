#!/usr/bin/env python3
"""Normalize the existing selection-function Monte Carlo into one R1 table."""
from pathlib import Path
import numpy as np
import pandas as pd


def main() -> None:
    src = Path("outputs_selection_function_mc/selection_mc_summary.csv")
    pop = Path("outputs_selection_function_mc/selection_mc_population.csv")
    outdir = Path("results/r1"); outdir.mkdir(parents=True, exist_ok=True)
    s = pd.read_csv(src); p = pd.read_csv(pop)
    observed_sigma = 2.996742212074611
    rows=[]
    for _, r in s.iterrows():
        q = p[(p.scenario==r.scenario)&(p.selection_mode==r.selection_mode)&(p.rv_fraction==r.rv_fraction)&p.status.eq("ok")]
        rows.append({"scenario":r.scenario,"selection_mode":r.selection_mode,"RV_retention":r.rv_fraction,"N_realizations":int(r.n_success),"N_surviving_clusters_median":float(q.n_clusters.median()) if len(q) else np.nan,"sigma_int_median":r.median_sigma_int_single,"sigma_int_p16":r.p16_sigma_int_single,"sigma_int_p84":r.p84_sigma_int_single,"prob_sigma_ge_observed":r.p_sigma_ge_observed,"observed_sigma_int":observed_sigma,"delta_BIC_broken_single_median":r.median_delta_bic_broken_vs_single,"notes":"sufficiency experiment; selection-only null is not attribution" if r.scenario=="selection_only_null" else "subsampling of observed Gaia RV members"})
    pd.DataFrame(rows).to_csv(outdir/"selection_scatter_summary.csv",index=False)
    print(f"Wrote {len(rows)} selection-function summary rows")


if __name__ == "__main__": main()
