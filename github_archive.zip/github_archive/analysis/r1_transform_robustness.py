#!/usr/bin/env python3
"""Audit the statistical upper boundary in the registered f_L transform."""
from __future__ import annotations

import argparse
from pathlib import Path
import numpy as np
import pandas as pd

from r1_age_inference import fit_all, load_data


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--population", type=Path, default=Path("outputs_v3/cluster_population.csv"))
    ap.add_argument("--unified", type=Path, default=Path("outputs_environment_regulation/unified_cluster_catalog.csv"))
    ap.add_argument("--external", type=Path, default=Path("outputs_independent_validation_sampling/external_cluster_validation.csv"))
    ap.add_argument("--outdir", type=Path, default=Path("results/r1"))
    args = ap.parse_args(); args.outdir.mkdir(parents=True, exist_ok=True)
    d = load_data(args.population, args.unified)
    rows = []
    for transform in ("logit", "log"):
        tab, _ = fit_all(d, transform=transform, intervals=True)
        s = tab.loc[tab.model.eq("single")].iloc[0]
        b = tab.loc[tab.model.eq("broken")].iloc[0]
        s0 = tab.loc[tab.model.eq("single_sigma0")].iloc[0]
        b0 = tab.loc[tab.model.eq("broken_sigma0")].iloc[0]
        rows.append({"transform": "logit(f_L)" if transform == "logit" else "log(f_L)", "N": len(d), "single_BIC": s.BIC, "broken_BIC": b.BIC, "delta_BIC_broken_single": b.BIC - s.BIC, "sigma_int": s.sigma_int, "slope": s.slope, "single_sigma0_BIC": s0.BIC, "broken_sigma0_BIC": b0.BIC, "delta_BIC_single_sigma0": s0.BIC - s.BIC, "notes": "logit uses registered [1e-4,1-1e-4] clip; log uses all positive raw f_L without upper boundary"})
    pd.DataFrame(rows).to_csv(args.outdir / "transform_robustness.csv", index=False)

    cases = []
    base = pd.read_csv(args.population)
    for _, r in base.iterrows():
        raw = float(r["f_L_raw"])
        if raw >= 1.0 - 1e-4:
            cases.append({"cluster": r["Name"], "ID": int(r["ID"]), "raw_fL": raw, "transformed_fL": float(r["f_L_v2"]), "source_experiment": "Gaia DR3 baseline outputs_v3/cluster_population.csv", "boundary_flag": "upper_clip"})
    if args.external.exists():
        ext = pd.read_csv(args.external)
        for _, r in ext[ext["status"].eq("ok")].iterrows():
            raw = float(r["f_L"])
            if raw >= 1.0 - 1e-4:
                cases.append({"cluster": r["Name"], "ID": int(r["ID"]), "raw_fL": raw, "transformed_fL": float(np.clip(raw, 1e-4, 1.0 - 1e-4)), "source_experiment": f"external validation {r['survey']}", "boundary_flag": "upper_clip"})
    pd.DataFrame(cases, columns=["cluster", "ID", "raw_fL", "transformed_fL", "source_experiment", "boundary_flag"]).sort_values(["source_experiment", "ID"]).to_csv(args.outdir / "fl_boundary_cases.csv", index=False)
    (args.outdir / "r1_transform_config.json").write_text('{\n  "transforms": ["logit(f_L) with registered clip", "log(f_L) positive raw"],\n  "upper_clip": 0.9999,\n  "lower_clip": 0.0001\n}\n')
    print(f"Wrote transform comparison and {len(cases)} boundary cases")


if __name__ == "__main__":
    main()
