#!/usr/bin/env python3
"""Monte Carlo Gaia DR3 radial-velocity selection-function experiment.

This script implements the experiment requested in ``selection_function_mc.txt``.
It uses the same Hunt+2024 member table and kinematic estimators as
``fossil_angular_momentum.py`` but caches each fitted cluster once, then
subsamples the available Gaia DR3 radial-velocity stars many times.

Two populations are refit for each realization:

``observed_subsample``
    Directly refits f_L after selecting a fraction of the currently available
    Gaia RV stars.

``selection_only_null``
    Removes the observed cluster-to-cluster residuals by centering every
    cluster on the best-fit single-power-law relation, then adds only the
    empirical logit(f_L) perturbation caused by RV subsampling. This is the
    direct test of whether selection noise alone can reproduce the observed
    intrinsic scatter.
"""

from __future__ import annotations

import argparse
import math
from dataclasses import dataclass
from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import expit

from fossil_angular_momentum import (
    CLUSTER_SPECS,
    KMS_PER_PC_TO_MYR_INV,
    MEMBER_SPECS,
    NUMERIC_CLUSTER_COLUMNS,
    NUMERIC_MEMBER_COLUMNS,
    finite_quality_members,
    fit_velocity_gradient,
    inertia_tensor_specific,
    omega_from_gradient,
    positions_relative_to_center,
    read_fwf,
    read_member_chunks,
    sigma3d,
    velocities_relative_to_center,
)
from scheme_v2_analysis import finite_logit
from scheme_v3_analysis import (
    broken_powerlaw_prediction,
    fit_broken_powerlaw,
    fit_single_powerlaw,
    single_powerlaw_prediction,
)


FRACTIONS = (0.20, 0.40, 0.60, 0.80, 1.00)
MODES = ("random", "magnitude_weighted")


@dataclass
class ClusterCache:
    cluster: pd.Series
    population: pd.Series
    all_pos: np.ndarray
    masses: np.ndarray
    rv_pos: np.ndarray
    rv_vel: np.ndarray
    rv_mag: np.ndarray
    inertia_specific: np.ndarray
    cluster_mass: float
    cluster_radius: float
    full_logit_f_l: float
    full_f_l: float
    n_full_rv: int


def rv_quality_mask(members: pd.DataFrame) -> pd.Series:
    return (
        members["RV"].notna()
        & np.isfinite(members["RV"])
        & members["e_RV"].notna()
        & (members["e_RV"] < 10)
        & ((members["RUWE"].isna()) | (members["RUWE"] < 1.4))
        & ((members["FidelityV1"].isna()) | (members["FidelityV1"] >= 0.5))
    )


def member_magnitude(df: pd.DataFrame) -> np.ndarray:
    grvs = df.get("GRVSmag", pd.Series(np.nan, index=df.index)).to_numpy(float)
    gmag = df.get("Gmag", pd.Series(np.nan, index=df.index)).to_numpy(float)
    mag = np.where(np.isfinite(grvs), grvs, gmag)
    finite = np.isfinite(mag)
    fallback = float(np.nanmedian(mag[finite])) if finite.any() else 15.0
    return np.where(finite, mag, fallback)


def fit_rv_selection_curve(good_members: pd.DataFrame) -> dict[str, float]:
    mag = member_magnitude(good_members)
    has_rv = rv_quality_mask(good_members).to_numpy(float)
    ok = np.isfinite(mag)
    mag = mag[ok]
    has_rv = has_rv[ok]
    if len(mag) < 100 or has_rv.sum() < 20:
        return {"mag_center": 13.0, "intercept": 0.0, "slope": -1.2, "n_members": int(len(mag))}

    center = float(np.nanmedian(mag))
    x = mag - center

    def objective(params: np.ndarray) -> float:
        p = expit(params[0] + params[1] * x)
        p = np.clip(p, 1e-6, 1.0 - 1e-6)
        return float(-np.sum(has_rv * np.log(p) + (1.0 - has_rv) * np.log1p(-p)))

    result = minimize(
        objective,
        x0=np.array([math.log((has_rv.mean() + 1e-3) / (1.0 - has_rv.mean() + 1e-3)), -1.0]),
        bounds=[(-12.0, 12.0), (-8.0, 2.0)],
        method="L-BFGS-B",
    )
    intercept, slope = result.x if result.success else (0.0, -1.2)
    return {
        "mag_center": center,
        "intercept": float(intercept),
        "slope": float(slope),
        "n_members": int(len(mag)),
        "n_rv": int(has_rv.sum()),
        "mean_rv_fraction": float(has_rv.mean()),
        "success": bool(result.success),
    }


def magnitude_selection_weights(mag: np.ndarray, params: dict[str, float]) -> np.ndarray:
    x = mag - params["mag_center"]
    weights = expit(params["intercept"] + params["slope"] * x)
    weights = np.clip(weights, 1e-6, None)
    if not np.isfinite(weights).all() or weights.sum() <= 0:
        return np.full(len(mag), 1.0 / len(mag))
    return weights / weights.sum()


def build_cluster_caches(
    population: pd.DataFrame,
    clusters_path: Path,
    members_path: Path,
    min_member_prob: float,
    use_star_parallax: bool,
) -> tuple[list[ClusterCache], dict[str, float]]:
    clusters = read_fwf(clusters_path, CLUSTER_SPECS, NUMERIC_CLUSTER_COLUMNS)
    ids = set(population["ID"].astype(int))
    members = read_member_chunks(members_path, MEMBER_SPECS, NUMERIC_MEMBER_COLUMNS, ids)
    clusters = clusters[clusters["ID"].isin(ids)].copy()

    good_chunks = []
    caches: list[ClusterCache] = []
    pop_by_id = population.set_index("ID", drop=False)
    cluster_by_id = clusters.set_index("ID", drop=False)

    for cluster_id in sorted(ids):
        if cluster_id not in cluster_by_id.index or cluster_id not in pop_by_id.index:
            continue
        cluster = cluster_by_id.loc[cluster_id]
        pop = pop_by_id.loc[cluster_id]
        cluster_members = members[members["ID"] == cluster_id].copy()
        good = finite_quality_members(cluster_members, min_member_prob)
        if good.empty:
            continue
        good_chunks.append(good)
        rv = good.loc[rv_quality_mask(good)].copy()
        if len(rv) < 5:
            continue
        try:
            all_pos = positions_relative_to_center(good, cluster, use_star_parallax)
            masses = good["Mass50"].to_numpy(float)
            rv_pos, rv_vel = velocities_relative_to_center(rv, cluster, use_star_parallax)
            _, gradient, residual = fit_velocity_gradient(rv_pos, rv_vel)
            inertia_specific = inertia_tensor_specific(all_pos, masses)
            cluster_mass = float(cluster.MassJ)
            cluster_radius = float(cluster.rJpc)
            vals = fast_diagnostic_values(inertia_specific, cluster_mass, cluster_radius, gradient, residual)
            full_f_l = float(vals["f_L"])
            if not np.isfinite(full_f_l) or full_f_l <= 0:
                continue
            caches.append(
                ClusterCache(
                    cluster=cluster,
                    population=pop,
                    all_pos=all_pos,
                    masses=masses,
                    rv_pos=rv_pos,
                    rv_vel=rv_vel,
                    rv_mag=member_magnitude(rv),
                    inertia_specific=inertia_specific,
                    cluster_mass=cluster_mass,
                    cluster_radius=cluster_radius,
                    full_logit_f_l=float(finite_logit(np.asarray([full_f_l]))[0]),
                    full_f_l=full_f_l,
                    n_full_rv=len(rv),
                )
            )
        except Exception:
            continue

    if not good_chunks:
        selection_params = {"mag_center": 13.0, "intercept": 0.0, "slope": -1.2, "n_members": 0}
    else:
        selection_params = fit_rv_selection_curve(pd.concat(good_chunks, ignore_index=True))
    return caches, selection_params


def select_indices(
    cache: ClusterCache,
    fraction: float,
    mode: str,
    selection_params: dict[str, float],
    rng: np.random.Generator,
) -> np.ndarray:
    n = cache.n_full_rv
    k = int(np.rint(fraction * n))
    k = max(1, min(k, n))
    if k == n:
        return np.arange(n)
    if mode == "magnitude_weighted":
        p = magnitude_selection_weights(cache.rv_mag, selection_params)
    else:
        p = None
    return np.sort(rng.choice(n, size=k, replace=False, p=p))


def fast_diagnostic_values(
    inertia_specific: np.ndarray,
    cluster_mass: float,
    cluster_radius: float,
    gradient: np.ndarray,
    residual: np.ndarray,
) -> dict[str, float]:
    omega = omega_from_gradient(gradient)
    omega_mag_myr = float(np.linalg.norm(omega * KMS_PER_PC_TO_MYR_INV))
    l_vec = cluster_mass * inertia_specific @ omega
    l_obs = float(np.linalg.norm(l_vec))
    sig3 = sigma3d(residual)
    l_vir = cluster_mass * cluster_radius * sig3 if sig3 > 0 else np.nan
    f_l = l_obs / l_vir if l_vir and np.isfinite(l_vir) and l_vir > 0 else np.nan
    return {
        "f_L": float(f_l),
        "sigma1d_kms": float(sig3 / math.sqrt(3.0)) if np.isfinite(sig3) else np.nan,
        "omega_mag_Myr_inv": omega_mag_myr,
    }


def refit_cache_subset(cache: ClusterCache, idx: np.ndarray) -> dict[str, float | int | str]:
    if len(idx) < 5:
        return {"status": "too_few_selected", "n_selected_rv": int(len(idx))}
    try:
        _, gradient, residual = fit_velocity_gradient(cache.rv_pos[idx], cache.rv_vel[idx])
        vals = fast_diagnostic_values(
            cache.inertia_specific,
            cache.cluster_mass,
            cache.cluster_radius,
            gradient,
            residual,
        )
        f_l = float(vals["f_L"])
        if not np.isfinite(f_l) or f_l <= 0:
            return {"status": "nonfinite_f_l", "n_selected_rv": int(len(idx))}
        return {
            "status": "ok",
            "n_selected_rv": int(len(idx)),
            "f_L": f_l,
            "f_L_v2": float(np.clip(f_l, 1e-4, 1.0 - 1e-4)),
            "logit_f_L": float(finite_logit(np.asarray([f_l]))[0]),
            "sigma1d_kms": float(vals["sigma1d_kms"]),
            "omega_mag_Myr_inv": float(vals["omega_mag_Myr_inv"]),
        }
    except Exception as exc:
        return {"status": f"failed:{type(exc).__name__}", "n_selected_rv": int(len(idx))}


def weighted_linear_fit(X: np.ndarray, y: np.ndarray, yerr: np.ndarray, n_iter: int = 8) -> dict[str, object]:
    sigma_int = 0.5
    beta = np.zeros(X.shape[1])
    for _ in range(n_iter):
        var = np.clip(yerr**2 + sigma_int**2, 1e-8, None)
        sw = 1.0 / np.sqrt(var)
        beta, *_ = np.linalg.lstsq(X * sw[:, None], y * sw, rcond=None)
        resid = y - X @ beta
        sigma2 = max(1e-10, float(np.mean(resid**2) - np.mean(yerr**2)))
        new_sigma = min(8.0, math.sqrt(sigma2))
        if abs(new_sigma - sigma_int) < 1e-4:
            sigma_int = new_sigma
            break
        sigma_int = new_sigma
    var = np.clip(yerr**2 + sigma_int**2, 1e-8, None)
    resid = y - X @ beta
    loglike = float(np.sum(-0.5 * (resid**2 / var + np.log(2.0 * np.pi * var))))
    return {"params": beta, "sigma_int": float(sigma_int), "loglike": loglike}


def fast_single_broken_fit(df: pd.DataFrame) -> dict[str, float]:
    y = df["logit_f_L"].to_numpy(float)
    x = np.log10(df["age_Myr"].to_numpy(float))
    yerr = df["logit_f_L_err"].to_numpy(float)
    n = len(y)

    single_x = np.column_stack([np.ones(n), x])
    single = weighted_linear_fit(single_x, y, yerr)
    single_bic = 3 * np.log(n) - 2.0 * float(single["loglike"])

    best: dict[str, object] | None = None
    for xb in np.linspace(np.log10(20.0), np.log10(1000.0), 70):
        broken_x = np.column_stack([np.ones(n), x, np.maximum(0.0, x - xb)])
        fit = weighted_linear_fit(broken_x, y, yerr)
        if best is None or float(fit["loglike"]) > float(best["loglike"]):
            best = {**fit, "break_age_Myr": float(10**xb)}
    assert best is not None
    broken_bic = 5 * np.log(n) - 2.0 * float(best["loglike"])
    return {
        "single_bic": float(single_bic),
        "broken_bic": float(broken_bic),
        "delta_bic_broken_vs_single": float(broken_bic - single_bic),
        "sigma_int_single": float(single["sigma_int"]),
        "sigma_int_broken": float(best["sigma_int"]),
        "break_age_Myr": float(best["break_age_Myr"]),
    }


def fit_population(df: pd.DataFrame, scenario: str, fraction: float, mode: str, iteration: int) -> dict[str, float | int | str]:
    ok = (
        np.isfinite(df["age_Myr"])
        & np.isfinite(df["logit_f_L"])
        & np.isfinite(df["logit_f_L_err"])
        & np.isfinite(df["f_L_v2"])
    )
    sub = df.loc[ok].copy().reset_index(drop=True)
    base = {
        "scenario": scenario,
        "rv_fraction": fraction,
        "selection_mode": mode,
        "iteration": iteration,
        "n_clusters": int(len(sub)),
    }
    if len(sub) < 12:
        base.update(
            {
                "status": "too_few_clusters",
                "single_bic": np.nan,
                "broken_bic": np.nan,
                "delta_bic_broken_vs_single": np.nan,
                "sigma_int_single": np.nan,
                "sigma_int_broken": np.nan,
                "break_age_Myr": np.nan,
            }
        )
        return base
    try:
        fast = fast_single_broken_fit(sub)
        base.update({"status": "ok", **fast})
    except Exception as exc:
        base.update(
            {
                "status": f"failed:{type(exc).__name__}",
                "single_bic": np.nan,
                "broken_bic": np.nan,
                "delta_bic_broken_vs_single": np.nan,
                "sigma_int_single": np.nan,
                "sigma_int_broken": np.nan,
                "break_age_Myr": np.nan,
            }
        )
    return base


def make_population_frames(
    cluster_rows: list[dict[str, float | int | str]],
    caches_by_id: dict[int, ClusterCache],
    single_params: np.ndarray,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    rows = []
    null_rows = []
    for row in cluster_rows:
        if row["status"] != "ok":
            continue
        cache = caches_by_id[int(row["ID"])]
        pop = cache.population
        age = float(pop["age_Myr"])
        base_err = float(pop["logit_f_L_err"])
        scaled_err = np.clip(base_err * math.sqrt(cache.n_full_rv / max(float(row["n_selected_rv"]), 1.0)), 0.25, 4.0)
        common = {
            "ID": int(row["ID"]),
            "Name": str(pop["Name"]),
            "age_Myr": age,
            "f_L_v2": float(row["f_L_v2"]),
            "n_RV_fit": int(row["n_selected_rv"]),
        }
        rows.append({**common, "logit_f_L": float(row["logit_f_L"]), "logit_f_L_err": float(scaled_err)})

        selection_delta = float(row["logit_f_L"] - cache.full_logit_f_l)
        smooth_mu = float(single_powerlaw_prediction(single_params, np.asarray([age]))[0])
        null_logit = smooth_mu + selection_delta
        null_rows.append(
            {
                **common,
                "f_L_v2": float(1.0 / (1.0 + np.exp(-np.clip(null_logit, -50.0, 50.0)))),
                "logit_f_L": null_logit,
                "logit_f_L_err": base_err,
                "selection_delta_logit": selection_delta,
            }
        )
    return pd.DataFrame(rows), pd.DataFrame(null_rows)


def summarize_population(population_mc: pd.DataFrame, observed_sigma: float, observed_delta_bic: float) -> pd.DataFrame:
    rows = []
    ok = population_mc["status"].eq("ok")
    for keys, sub in population_mc.loc[ok].groupby(["scenario", "selection_mode", "rv_fraction"]):
        scenario, mode, fraction = keys
        sigma = sub["sigma_int_single"].to_numpy(float)
        delta = sub["delta_bic_broken_vs_single"].to_numpy(float)
        tb = sub["break_age_Myr"].to_numpy(float)
        rows.append(
            {
                "scenario": scenario,
                "selection_mode": mode,
                "rv_fraction": float(fraction),
                "n_success": int(len(sub)),
                "median_sigma_int_single": float(np.nanmedian(sigma)),
                "p16_sigma_int_single": float(np.nanpercentile(sigma, 16)),
                "p84_sigma_int_single": float(np.nanpercentile(sigma, 84)),
                "median_delta_bic_broken_vs_single": float(np.nanmedian(delta)),
                "p16_delta_bic_broken_vs_single": float(np.nanpercentile(delta, 16)),
                "p84_delta_bic_broken_vs_single": float(np.nanpercentile(delta, 84)),
                "median_break_age_Myr": float(np.nanmedian(tb)),
                "p16_break_age_Myr": float(np.nanpercentile(tb, 16)),
                "p84_break_age_Myr": float(np.nanpercentile(tb, 84)),
                "p_sigma_ge_observed": float(np.nanmean(sigma >= observed_sigma)),
                "p_broken_bic_at_least_observed": float(np.nanmean(delta <= observed_delta_bic)),
                "p_broken_preferred": float(np.nanmean(delta < 0.0)),
                "p_strong_broken_preferred": float(np.nanmean(delta < -6.0)),
            }
        )
    return pd.DataFrame(rows).sort_values(["scenario", "selection_mode", "rv_fraction"])


def summarize_clusters(cluster_mc: pd.DataFrame) -> pd.DataFrame:
    ok = cluster_mc["status"].eq("ok")
    rows = []
    for keys, sub in cluster_mc.loc[ok].groupby(["ID", "Name", "selection_mode", "rv_fraction"]):
        cluster_id, name, mode, fraction = keys
        f_l = sub["f_L"].to_numpy(float)
        rows.append(
            {
                "ID": int(cluster_id),
                "Name": name,
                "selection_mode": mode,
                "rv_fraction": float(fraction),
                "n_success": int(len(sub)),
                "median_f_L": float(np.nanmedian(f_l)),
                "p16_f_L": float(np.nanpercentile(f_l, 16)),
                "p84_f_L": float(np.nanpercentile(f_l, 84)),
                "sd_logit_f_L": float(np.nanstd(sub["logit_f_L"].to_numpy(float), ddof=1)),
                "median_n_selected_rv": float(np.nanmedian(sub["n_selected_rv"].to_numpy(float))),
            }
        )
    return pd.DataFrame(rows).sort_values(["selection_mode", "rv_fraction", "ID"])


def make_intrinsic_scatter_figure(summary: pd.DataFrame, observed_sigma: float, outdir: Path) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.5), sharey=True, constrained_layout=True)
    colors = {"random": "0.25", "magnitude_weighted": "steelblue"}
    titles = {"selection_only_null": "Selection-only null", "observed_subsample": "Observed subsamples"}
    for ax, scenario in zip(axes, ["selection_only_null", "observed_subsample"]):
        for mode in MODES:
            sub = summary[(summary["scenario"] == scenario) & (summary["selection_mode"] == mode)].sort_values("rv_fraction")
            if sub.empty:
                continue
            x = 100.0 * sub["rv_fraction"].to_numpy(float)
            y = sub["median_sigma_int_single"].to_numpy(float)
            lo = sub["p16_sigma_int_single"].to_numpy(float)
            hi = sub["p84_sigma_int_single"].to_numpy(float)
            ax.plot(x, y, marker="o", color=colors[mode], lw=1.7, label=mode.replace("_", " "))
            ax.fill_between(x, lo, hi, color=colors[mode], alpha=0.18, lw=0)
        ax.axhline(observed_sigma, color="firebrick", lw=1.2, ls="--", label="observed")
        ax.set_title(titles[scenario])
        ax.set_xlabel("Retained Gaia RV stars (%)")
        ax.set_xlim(15, 105)
        ax.grid(True, color="0.9", lw=0.7)
    axes[0].set_ylabel(r"Recovered $\sigma_{\rm int}$ in logit($f_L$)")
    axes[0].legend(frameon=False, fontsize=8)
    fig.savefig(outdir / "figure_selection_intrinsic_scatter_vs_completeness.png", dpi=260)
    plt.close(fig)


def make_break_distribution_figure(population_mc: pd.DataFrame, outdir: Path) -> None:
    plot = population_mc[
        population_mc["status"].eq("ok")
        & population_mc["scenario"].eq("selection_only_null")
        & np.isfinite(population_mc["break_age_Myr"])
    ].copy()
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.5), sharey=True, constrained_layout=True)
    for ax, mode in zip(axes, MODES):
        sub = plot[plot["selection_mode"].eq(mode)]
        data = [
            sub.loc[sub["rv_fraction"].eq(frac), "break_age_Myr"].to_numpy(float)
            for frac in FRACTIONS
        ]
        ax.boxplot(data, positions=np.arange(len(FRACTIONS)), widths=0.62, showfliers=False)
        ax.set_xticks(np.arange(len(FRACTIONS)))
        ax.set_xticklabels([f"{int(100*f)}" for f in FRACTIONS])
        ax.set_title(mode.replace("_", " "))
        ax.set_xlabel("Retained Gaia RV stars (%)")
        ax.grid(True, axis="y", color="0.9", lw=0.7)
    axes[0].set_ylabel(r"Recovered broken-model $t_b$ (Myr)")
    fig.savefig(outdir / "figure_selection_break_age_distribution.png", dpi=260)
    plt.close(fig)


def make_bic_distribution_figure(population_mc: pd.DataFrame, observed_delta_bic: float, outdir: Path) -> None:
    plot = population_mc[
        population_mc["status"].eq("ok")
        & population_mc["scenario"].eq("selection_only_null")
        & np.isfinite(population_mc["delta_bic_broken_vs_single"])
    ].copy()
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.5), sharey=True, constrained_layout=True)
    for ax, mode in zip(axes, MODES):
        sub = plot[plot["selection_mode"].eq(mode)]
        data = [
            sub.loc[sub["rv_fraction"].eq(frac), "delta_bic_broken_vs_single"].to_numpy(float)
            for frac in FRACTIONS
        ]
        ax.boxplot(data, positions=np.arange(len(FRACTIONS)), widths=0.62, showfliers=False)
        ax.axhline(0.0, color="black", lw=1.0)
        ax.axhline(observed_delta_bic, color="firebrick", lw=1.1, ls="--")
        ax.set_xticks(np.arange(len(FRACTIONS)))
        ax.set_xticklabels([f"{int(100*f)}" for f in FRACTIONS])
        ax.set_title(mode.replace("_", " "))
        ax.set_xlabel("Retained Gaia RV stars (%)")
        ax.grid(True, axis="y", color="0.9", lw=0.7)
    axes[0].set_ylabel(r"$\Delta{\rm BIC}_{\rm broken-single}$")
    fig.savefig(outdir / "figure_selection_bic_distribution.png", dpi=260)
    plt.close(fig)


def write_text_products(
    summary: pd.DataFrame,
    observed_sigma: float,
    observed_delta_bic: float,
    observed_break: float,
    selection_params: dict[str, float],
    n_clusters: int,
    realizations: int,
    outdir: Path,
) -> None:
    null_mag_20 = summary[
        summary["scenario"].eq("selection_only_null")
        & summary["selection_mode"].eq("magnitude_weighted")
        & summary["rv_fraction"].eq(0.20)
    ].iloc[0]
    null_mag_100 = summary[
        summary["scenario"].eq("selection_only_null")
        & summary["selection_mode"].eq("magnitude_weighted")
        & summary["rv_fraction"].eq(1.00)
    ].iloc[0]
    obs_mag_20 = summary[
        summary["scenario"].eq("observed_subsample")
        & summary["selection_mode"].eq("magnitude_weighted")
        & summary["rv_fraction"].eq(0.20)
    ].iloc[0]

    conclusion = (
        "The selection-only null does not reproduce the observed intrinsic scatter."
        if float(null_mag_20["p_sigma_ge_observed"]) < 0.05
        else "The selection-only null can reproduce the observed intrinsic scatter in a non-negligible fraction of trials."
    )

    methods = rf"""\subsection{{Radial-velocity selection-function Monte Carlo}}
We tested whether Gaia DR3 radial-velocity incompleteness can by itself generate the population-level scatter in $f_L$.  For each of the {n_clusters} fitted clusters we cached the high-probability Hunt et al. member positions, masses, and the Gaia DR3 RV-member phase-space coordinates used in the fiducial kinematic fit.  We then repeated the velocity-gradient measurement after retaining fixed fractions of the available RV stars, $f_{{\rm RV}}=0.2,0.4,0.6,0.8,$ and $1.0$, for {realizations} Monte Carlo realizations per fraction.  We considered both uniform random removal and a magnitude-weighted selection.  The latter used an empirical logistic model for the probability that a quality member has a Gaia DR3 RV as a function of $G_{{\rm RVS}}$ (falling back to $G$ where necessary); the fitted slope was {selection_params.get('slope', float('nan')):.3f} about a median magnitude of {selection_params.get('mag_center', float('nan')):.2f}.

For every realization we recomputed $f_L$, refit the single and broken power-law population models in logit($f_L$)-age space, and recorded the recovered intrinsic scatter, broken-model break age, and $\Delta{{\rm BIC}}_{{\rm broken-single}}$.  To isolate selection effects from the actual cluster-to-cluster residuals, we also constructed a selection-only null sample in which each cluster was placed on the fiducial single-power-law relation and only the measured subsampling perturbation $\Delta\logit(f_L)$ was added back.
"""

    discussion = rf"""\subsection{{Can Gaia RV selection explain the intrinsic scatter?}}
The observed single-power-law fit requires $\sigma_{{\rm int}}={observed_sigma:.2f}$ in logit($f_L$), while the observed broken-model comparison gives $\Delta{{\rm BIC}}_{{\rm broken-single}}={observed_delta_bic:.2f}$ and $t_b={observed_break:.1f}$ Myr.  In the magnitude-weighted selection-only null, even the most severe 20\% RV-retention experiment recovers a median $\sigma_{{\rm int}}={null_mag_20['median_sigma_int_single']:.2f}$ with a 16--84\% range of {null_mag_20['p16_sigma_int_single']:.2f}--{null_mag_20['p84_sigma_int_single']:.2f}; the probability of reaching the observed scatter is {100.0 * null_mag_20['p_sigma_ge_observed']:.1f}\%.  At 100\% retention the corresponding null scatter is {null_mag_100['median_sigma_int_single']:.2f}, as expected for a sample centered on the smooth relation.

The direct observed-subsample experiment is deliberately less diagnostic because it retains the real cluster-to-cluster diversity already present in the Gaia-only measurements.  It gives a 20\% magnitude-weighted median $\sigma_{{\rm int}}={obs_mag_20['median_sigma_int_single']:.2f}$, showing that degrading the available RV sample does not remove the need for population scatter.  {conclusion}  The experiment therefore treats Gaia RV incompleteness as an important measurement-noise contribution, not as a sufficient explanation for the full intrinsic scatter inferred in the fiducial population model.
"""

    appendix = rf"""\section{{Selection-function Monte Carlo}}
The selection-function stress test used all fitted clusters and five RV-retention fractions.  The output tables report the direct cluster-level refits, population-level model comparisons, and aggregate summaries for both random and magnitude-weighted selection.  The principal diagnostic is the selection-only null, which removes the observed residual structure before adding the RV-subsampling perturbation.  In this null, the median $\sigma_{{\rm int}}$ under 20\% magnitude-weighted retention is {null_mag_20['median_sigma_int_single']:.2f}, compared with the observed {observed_sigma:.2f}.  The corresponding probability of matching or exceeding the observed scatter is {100.0 * null_mag_20['p_sigma_ge_observed']:.1f}\%.  The recovered broken-model BIC remains centered at $\Delta{{\rm BIC}}_{{\rm broken-single}}={null_mag_20['median_delta_bic_broken_vs_single']:.2f}$ for the same experiment, with a broken-model preference in {100.0 * null_mag_20['p_broken_preferred']:.1f}\% of realizations.
"""

    summary_md = "\n".join(
        [
            "# Selection-function Monte Carlo",
            "",
            f"Clusters cached: {n_clusters}",
            f"Realizations per fraction/mode: {realizations}",
            f"Observed sigma_int(single): {observed_sigma:.3f}",
            f"Observed Delta BIC(broken-single): {observed_delta_bic:.3f}",
            f"Observed broken break age: {observed_break:.3f} Myr",
            "",
            "## Main conclusion",
            "",
            conclusion,
            "",
            "## Key magnitude-weighted selection-only null result",
            "",
            (
                f"At 20% RV retention, sigma_int = {null_mag_20['median_sigma_int_single']:.3f} "
                f"({null_mag_20['p16_sigma_int_single']:.3f}-{null_mag_20['p84_sigma_int_single']:.3f}), "
                f"P(sigma_int >= observed) = {null_mag_20['p_sigma_ge_observed']:.3f}."
            ),
            "",
            "## Outputs",
            "",
            "- `selection_mc_population.csv`: one row per population refit.",
            "- `selection_mc_cluster_summary.csv`: per-cluster f_L summaries.",
            "- `selection_mc_cluster_draws.csv.gz`: per-cluster Monte Carlo draws.",
            "- `figure_selection_intrinsic_scatter_vs_completeness.png`.",
            "- `figure_selection_break_age_distribution.png`.",
            "- `figure_selection_bic_distribution.png`.",
            "- `methods_selection_function_mc.tex`, `discussion_selection_function_mc.tex`, `appendix_selection_function_mc.tex`.",
        ]
    )

    (outdir / "methods_selection_function_mc.tex").write_text(methods + "\n")
    (outdir / "discussion_selection_function_mc.tex").write_text(discussion + "\n")
    (outdir / "appendix_selection_function_mc.tex").write_text(appendix + "\n")
    (outdir / "summary.md").write_text(summary_md + "\n")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--population", type=Path, default=Path("outputs_v3/cluster_population.csv"))
    parser.add_argument("--clusters", type=Path, default=Path("hunt24/clusters.dat"))
    parser.add_argument("--members", type=Path, default=Path("hunt24/members.dat"))
    parser.add_argument("--outdir", type=Path, default=Path("outputs_selection_function_mc"))
    parser.add_argument("--realizations", type=int, default=1000)
    parser.add_argument("--seed", type=int, default=20260707)
    parser.add_argument("--min-member-prob", type=float, default=0.5)
    parser.add_argument("--use-star-parallax", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(args.seed)

    population = pd.read_csv(args.population)
    population = population[
        (population["status"] == "ok")
        & np.isfinite(population["age_Myr"])
        & np.isfinite(population["logit_f_L"])
        & np.isfinite(population["logit_f_L_err"])
        & np.isfinite(population["f_L_v2"])
    ].copy()

    observed_single = fit_single_powerlaw(population)
    observed_broken = fit_broken_powerlaw(population)
    observed_sigma = float(observed_single["sigma_int"])
    observed_delta_bic = float(observed_broken["bic"] - observed_single["bic"])
    observed_break = float(np.exp(observed_broken["params"][3]))

    caches, selection_params = build_cluster_caches(
        population,
        args.clusters,
        args.members,
        args.min_member_prob,
        args.use_star_parallax,
    )
    if len(caches) < 12:
        raise RuntimeError(f"Too few cluster caches built: {len(caches)}")
    caches_by_id = {int(cache.population["ID"]): cache for cache in caches}
    single_params = np.asarray(observed_single["params"])

    baseline_rows = []
    for cache in caches:
        baseline_rows.append(
            {
                "ID": int(cache.population["ID"]),
                "Name": str(cache.population["Name"]),
                "age_Myr": float(cache.population["age_Myr"]),
                "n_full_rv": int(cache.n_full_rv),
                "population_f_L": float(cache.population["f_L_v2"]),
                "cached_full_f_L": float(np.clip(cache.full_f_l, 1e-4, 1.0 - 1e-4)),
                "population_logit_f_L": float(cache.population["logit_f_L"]),
                "cached_full_logit_f_L": float(cache.full_logit_f_l),
            }
        )
    pd.DataFrame(baseline_rows).to_csv(args.outdir / "selection_mc_baseline_clusters.csv", index=False)
    pd.DataFrame([selection_params]).to_csv(args.outdir / "gaia_rv_selection_curve.csv", index=False)

    cluster_draws: list[dict[str, float | int | str]] = []
    population_rows: list[dict[str, float | int | str]] = []

    for mode in MODES:
        for fraction in FRACTIONS:
            for iteration in range(args.realizations):
                draw_rows: list[dict[str, float | int | str]] = []
                for cache in caches:
                    idx = select_indices(cache, fraction, mode, selection_params, rng)
                    row = refit_cache_subset(cache, idx)
                    row.update(
                        {
                            "ID": int(cache.population["ID"]),
                            "Name": str(cache.population["Name"]),
                            "age_Myr": float(cache.population["age_Myr"]),
                            "selection_mode": mode,
                            "rv_fraction": fraction,
                            "iteration": iteration,
                            "n_full_rv": int(cache.n_full_rv),
                        }
                    )
                    draw_rows.append(row)
                cluster_draws.extend(draw_rows)
                observed_df, null_df = make_population_frames(draw_rows, caches_by_id, single_params)
                population_rows.append(fit_population(observed_df, "observed_subsample", fraction, mode, iteration))
                population_rows.append(fit_population(null_df, "selection_only_null", fraction, mode, iteration))

    cluster_mc = pd.DataFrame(cluster_draws)
    population_mc = pd.DataFrame(population_rows)
    summary = summarize_population(population_mc, observed_sigma, observed_delta_bic)
    cluster_summary = summarize_clusters(cluster_mc)

    population_mc.to_csv(args.outdir / "selection_mc_population.csv", index=False)
    summary.to_csv(args.outdir / "selection_mc_summary.csv", index=False)
    cluster_summary.to_csv(args.outdir / "selection_mc_cluster_summary.csv", index=False)
    cluster_mc.to_csv(args.outdir / "selection_mc_cluster_draws.csv.gz", index=False, compression="gzip")

    make_intrinsic_scatter_figure(summary, observed_sigma, args.outdir)
    make_break_distribution_figure(population_mc, args.outdir)
    make_bic_distribution_figure(population_mc, observed_delta_bic, args.outdir)
    write_text_products(
        summary,
        observed_sigma,
        observed_delta_bic,
        observed_break,
        selection_params,
        len(caches),
        args.realizations,
        args.outdir,
    )

    main_row = summary[
        summary["scenario"].eq("selection_only_null")
        & summary["selection_mode"].eq("magnitude_weighted")
        & summary["rv_fraction"].eq(0.20)
    ].iloc[0]
    print(f"Cached clusters: {len(caches)}")
    print(f"Observed sigma_int(single): {observed_sigma:.3f}")
    print(
        "20% magnitude-weighted selection-only sigma_int: "
        f"{main_row['median_sigma_int_single']:.3f} "
        f"({main_row['p16_sigma_int_single']:.3f}-{main_row['p84_sigma_int_single']:.3f})"
    )
    print(f"P(selection-only sigma >= observed): {main_row['p_sigma_ge_observed']:.3f}")
    print(f"Wrote outputs to {args.outdir}")


if __name__ == "__main__":
    main()
