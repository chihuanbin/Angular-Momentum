# Gaia DR3 Constraints on Angular-Momentum Diversity in Galactic Open Clusters

This directory is the GitHub handoff archive for the frozen A&A R1 analysis.
It contains the R1 analysis scripts, the machine-readable inputs and results
needed to inspect the reported numbers, the provenance records, and the
submission figures. It is intentionally a compact reproducibility archive,
not a mirror of every upstream catalogue file.

## Scope and status

- Manuscript: `Gaia DR3 Constraints on Angular-Momentum Diversity in Galactic Open Clusters`.
- Revision state: A&A R1 closure; scientific results are frozen.
- Baseline population: 125 fitted clusters.
- Main observable: the continuous estimator response `f_L`, analysed with the
  registered logit transform and quoted measurement uncertainties.
- No scientific analysis is run by merely unpacking this directory.

The archive does not include generated Python caches or the complete upstream
member-star tables; the final `main.log` is retained only as a build-trace
input for the provenance audit. The full Hunt--Reffert
`members.dat` table is about 1.4 GB, and the local LAMOST `dr11sl.dat` source
table is about 4.1 GB. Their catalogue identifiers, provenance, and the small
derived tables used by the R1 products are retained here. Retrieve those
upstream files from their official catalogue records when a full star-level
rerun is required.

## Layout

| Path | Contents |
|---|---|
| `analysis/` | R1 analysis, audit, plotting, and traceability scripts |
| `fossil_angular_momentum.py`, `scheme_v2_analysis.py`, `scheme_v3_analysis.py`, `selection_function_mc_analysis.py` | Small dependency scripts required by the archived R1 code paths |
| `outputs_v3/`, `outputs_environment_regulation/` | Frozen derived Gaia population inputs |
| `outputs_selection_function_mc/`, `outputs_synthetic_cluster_recovery/` | Frozen selection and synthetic-calibration summaries |
| `outputs_hierarchical_bayes/`, `outputs_independent_validation_sampling/` | Frozen hierarchical and matched external-RV products |
| `external_rv_data/` | Small source-ID-matched APOGEE, GALAH, and LAMOST extracts plus provenance |
| `hunt24/` | Hunt--Reffert cluster catalogue table and its original ReadMe; the large member table is not duplicated |
| `results/r1/` | Machine-readable R1 result tables and configuration files |
| `revision/audit/` | Claim, number-traceability, unit, provenance, and closure audits |
| `revision/manuscript/` | Clean manuscript source, bibliography/class files, figures, and compiled PDF |
| `provenance/` | Hash-based R1 provenance manifest and its generator |
| `metadata/` | Data dictionary, archive manifest, and environment notes |

## Minimal environment

The R1 scripts use Python 3.9 or newer and the packages listed in
`metadata/requirements-r1.txt`. Run commands from this directory so that the
relative paths used by the frozen scripts resolve correctly. For example:

```bash
cd github_archive
python3 analysis/r1_constant_age_null.py \
  --population outputs_v3/cluster_population.csv \
  --unified outputs_environment_regulation/unified_cluster_catalog.csv \
  --outdir results/r1_recomputed
```

The command above writes a new comparison directory and does not overwrite
the archived results. The complete star-level selection Monte Carlo requires
the upstream Hunt--Reffert member table; the archived selection summary and
its provenance remain available without that multi-gigabyte file.

## Provenance and integrity

`provenance/r1_provenance.json` records the source/output relationships,
configuration files, random seeds, sample sizes, and SHA-256 hashes used for
the R1 closure. `metadata/SHA256SUMS` provides hashes for the files in this
GitHub archive. Rebuild the latter only after an intentional archive update.

## Data and code status

The Gaia, Hunt--Reffert, APOGEE, GALAH, and LAMOST products are reused or
derived third-party catalogue material. Their original catalogue citations
and access conditions apply; this archive does not relicense them. Code and
derived tables do not yet carry an author-approved open-source/data licence.
See `metadata/LICENSE_STATUS.md` and add the authors' chosen licence before
public release.

## Citation

Use the manuscript citation for the scientific result. For this archive,
`CITATION.cff` contains the current author and version metadata. Do not add a
DOI or repository URL until the GitHub repository and an archival release
record have actually been created.
