#!/usr/bin/env python3
"""Run the scheme_v2 two-phase despinning analysis.

This script consumes the first-pass kinematic measurements produced by
``fossil_angular_momentum.py`` and upgrades the population model from a single
power law to a two-phase, mixture-aware hierarchical model.
"""

from __future__ import annotations

import argparse
import math
from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.optimize import least_squares
from scipy.special import expit, logit


CLUSTER_ENV_SPECS = {
    "Name": (0, 20),
    "ID": (21, 25),
    "X_pc": (640, 656),
    "Y_pc": (657, 673),
    "Z_pc": (674, 690),
    "r50pc": (418, 431),
    "r50Jpc": (964, 976),
    "rJpc": (977, 990),
}


def read_cluster_environment(path: Path) -> pd.DataFrame:
    names = list(CLUSTER_ENV_SPECS)
    colspecs = [CLUSTER_ENV_SPECS[name] for name in names]
    df = pd.read_fwf(path, colspecs=colspecs, names=names, dtype=str, keep_default_na=False)
    for col in df.columns:
        df[col] = df[col].astype(str).str.strip()
    for col in ["ID", "X_pc", "Y_pc", "Z_pc", "r50pc", "r50Jpc", "rJpc"]:
        values = df[col].mask(df[col].isin(["", "?"]), np.nan)
        df[col] = pd.to_numeric(values, errors="coerce")
    df["R_GC_kpc"] = np.sqrt(df["X_pc"] ** 2 + df["Y_pc"] ** 2) / 1000.0
    df["abs_Z_kpc"] = np.abs(df["Z_pc"]) / 1000.0
    return df


def finite_logit(values: np.ndarray, eps: float = 1e-4) -> np.ndarray:
    return logit(np.clip(values, eps, 1.0 - eps))


def prepare_v2_data(results_path: Path, clusters_path: Path) -> pd.DataFrame:
    results = pd.read_csv(results_path)
    env = read_cluster_environment(clusters_path)
    df = results.merge(env[["ID", "R_GC_kpc", "abs_Z_kpc", "r50pc"]], on="ID", how="left")
    ok = (
        (df["status"] == "ok")
        & np.isfinite(df["f_L"])
        & (df["f_L"] > 0)
        & np.isfinite(df["age_Myr"])
        & np.isfinite(df["R_GC_kpc"])
        & np.isfinite(df["sigma1d_kms"])
    )
    df = df.loc[ok].copy().reset_index(drop=True)

    df["f_L_raw"] = df["f_L"]
    df["f_L_v2"] = df["f_L_raw"].clip(1e-4, 1.0 - 1e-4)
    df["is_virial_excess"] = df["f_L_raw"] >= 1.0
    df["logit_f_L"] = finite_logit(df["f_L_v2"].to_numpy(float))

    p16 = df.get("f_L_p16", pd.Series(np.nan, index=df.index)).to_numpy(float)
    p84 = df.get("f_L_p84", pd.Series(np.nan, index=df.index)).to_numpy(float)
    yerr = 0.5 * (finite_logit(p84) - finite_logit(p16))
    yerr = np.where(np.isfinite(yerr) & (yerr > 0), yerr, 0.5)
    df["logit_f_L_err"] = np.clip(yerr, 0.25, 2.0)

    df["r_h_pc"] = df["r50Jpc"].where(np.isfinite(df["r50Jpc"]), df["r50pc"])
    df["r_h_pc"] = df["r_h_pc"].where(np.isfinite(df["r_h_pc"]), 0.5 * df["rJpc"])
    for col in ["R_GC_kpc", "r_h_pc", "sigma1d_kms"]:
        mean = float(df[col].mean())
        std = float(df[col].std(ddof=0)) or 1.0
        df[f"{col}_z"] = (df[col] - mean) / std
    return df


def two_phase_numpyro_model(age, r_gc_z, r_h_z, sigma_z, yerr, y=None):
    import jax.numpy as jnp
    import numpyro
    import numpyro.distributions as dist
    from jax.nn import sigmoid, softplus
    from jax.scipy.special import logsumexp

    logit_f0 = numpyro.sample("logit_f0", dist.Normal(0.4, 1.0))
    log_tau_gas = numpyro.sample("log_tau_gas", dist.Normal(jnp.log(80.0), 0.45))
    log_t_break = numpyro.sample("log_t_break", dist.Normal(jnp.log(100.0), 0.35))
    beta0 = numpyro.sample("beta0", dist.Normal(0.2, 0.7))
    beta_r_gc = numpyro.sample("beta_r_gc", dist.Normal(0.0, 0.45))
    beta_r_h = numpyro.sample("beta_r_h", dist.Normal(0.0, 0.35))
    beta_sigma = numpyro.sample("beta_sigma", dist.Normal(0.0, 0.35))
    sigma_int = numpyro.sample("sigma_int", dist.HalfNormal(0.6))
    mu_bad = numpyro.sample("mu_bad", dist.Normal(-1.0, 2.0))
    sigma_bad = numpyro.sample("sigma_bad", dist.HalfNormal(1.5))
    p_good = numpyro.sample("p_good", dist.Beta(4.0, 2.0))

    tau_gas = jnp.exp(log_tau_gas)
    t_break = jnp.exp(log_t_break)
    beta_eff = softplus(beta0 + beta_r_gc * r_gc_z + beta_r_h * r_h_z + beta_sigma * sigma_z) + 0.05
    f0 = sigmoid(logit_f0)
    f_model = f0 * jnp.exp(-age / tau_gas) / (1.0 + (age / t_break) ** beta_eff)
    f_model = jnp.clip(f_model, 1e-5, 1.0 - 1e-5)
    mu_good = jnp.log(f_model) - jnp.log1p(-f_model)
    sigma_good = jnp.sqrt(yerr**2 + sigma_int**2)

    numpyro.deterministic("tau_gas_Myr", tau_gas)
    numpyro.deterministic("t_break_Myr", t_break)
    numpyro.deterministic("beta_eff_at_mean_env", softplus(beta0) + 0.05)

    good_lp = jnp.log(p_good) + dist.Normal(mu_good, sigma_good).log_prob(y)
    bad_lp = jnp.log1p(-p_good) + dist.Normal(mu_bad, sigma_bad + 0.25).log_prob(y)
    numpyro.factor("mixture_log_likelihood", logsumexp(jnp.stack([good_lp, bad_lp]), axis=0).sum())


def run_numpyro_model(df: pd.DataFrame, warmup: int, samples: int, seed: int):
    import jax.numpy as jnp
    from jax import random
    from numpyro.infer import MCMC, NUTS

    data = {
        "age": jnp.asarray(df["age_Myr"].to_numpy(float)),
        "r_gc_z": jnp.asarray(df["R_GC_kpc_z"].to_numpy(float)),
        "r_h_z": jnp.asarray(df["r_h_pc_z"].to_numpy(float)),
        "sigma_z": jnp.asarray(df["sigma1d_kms_z"].to_numpy(float)),
        "yerr": jnp.asarray(df["logit_f_L_err"].to_numpy(float)),
        "y": jnp.asarray(df["logit_f_L"].to_numpy(float)),
    }
    kernel = NUTS(two_phase_numpyro_model, target_accept_prob=0.85)
    mcmc = MCMC(kernel, num_warmup=warmup, num_samples=samples, num_chains=1, progress_bar=False)
    mcmc.run(random.PRNGKey(seed), **data)
    return {key: np.asarray(value) for key, value in mcmc.get_samples().items()}


def posterior_curves(samples: dict[str, np.ndarray], age_grid: np.ndarray) -> np.ndarray:
    logit_f0 = samples["logit_f0"]
    tau = samples["tau_gas_Myr"]
    tb = samples["t_break_Myr"]
    beta = samples["beta_eff_at_mean_env"]
    f0 = expit(logit_f0)
    curves = []
    for f0_i, tau_i, tb_i, beta_i in zip(f0, tau, tb, beta):
        curve = f0_i * np.exp(-age_grid / tau_i) / (1.0 + (age_grid / tb_i) ** beta_i)
        curves.append(np.clip(curve, 1e-5, 1.0 - 1e-5))
    return np.asarray(curves)


def posterior_good_probabilities(df: pd.DataFrame, samples: dict[str, np.ndarray]) -> np.ndarray:
    age = df["age_Myr"].to_numpy(float)
    rgc = df["R_GC_kpc_z"].to_numpy(float)
    rh = df["r_h_pc_z"].to_numpy(float)
    sig = df["sigma1d_kms_z"].to_numpy(float)
    y = df["logit_f_L"].to_numpy(float)
    yerr = df["logit_f_L_err"].to_numpy(float)

    probs = []
    for i in range(len(samples["logit_f0"])):
        f0 = expit(samples["logit_f0"][i])
        tau = samples["tau_gas_Myr"][i]
        tb = samples["t_break_Myr"][i]
        beta_linear = (
            samples["beta0"][i]
            + samples["beta_r_gc"][i] * rgc
            + samples["beta_r_h"][i] * rh
            + samples["beta_sigma"][i] * sig
        )
        beta_eff = np.log1p(np.exp(beta_linear)) + 0.05
        f_model = np.clip(f0 * np.exp(-age / tau) / (1.0 + (age / tb) ** beta_eff), 1e-5, 1.0 - 1e-5)
        mu_good = finite_logit(f_model)
        sig_good = np.sqrt(yerr**2 + samples["sigma_int"][i] ** 2)
        p_good = samples["p_good"][i]

        good_lp = np.log(p_good) - 0.5 * ((y - mu_good) / sig_good) ** 2 - np.log(sig_good)
        bad_sig = samples["sigma_bad"][i] + 0.25
        bad_lp = np.log1p(-p_good) - 0.5 * ((y - samples["mu_bad"][i]) / bad_sig) ** 2 - np.log(bad_sig)
        max_lp = np.maximum(good_lp, bad_lp)
        probs.append(np.exp(good_lp - max_lp) / (np.exp(good_lp - max_lp) + np.exp(bad_lp - max_lp)))
    return np.mean(np.asarray(probs), axis=0)


def weighted_loglike(y: np.ndarray, yhat: np.ndarray, yerr: np.ndarray) -> float:
    var = yerr**2
    return float(np.sum(-0.5 * ((y - yhat) ** 2 / var + np.log(2.0 * np.pi * var))))


def bic_transition_diagnostic(df: pd.DataFrame) -> dict[str, float]:
    y = df["logit_f_L"].to_numpy(float)
    age = df["age_Myr"].to_numpy(float)
    err = df["logit_f_L_err"].to_numpy(float)
    log_age = np.log10(age / 100.0)

    def power_resid(p):
        return (y - (p[0] + p[1] * log_age)) / err

    power = least_squares(power_resid, x0=np.array([-1.8, -0.2]))
    ll_power = weighted_loglike(y, power.x[0] + power.x[1] * log_age, err)

    def two_phase_prediction(p):
        logit_f0, log_tau, log_tb, log_beta = p
        f0 = expit(logit_f0)
        tau = np.exp(log_tau)
        tb = np.exp(log_tb)
        beta = np.exp(log_beta)
        f = np.clip(f0 * np.exp(-age / tau) / (1.0 + (age / tb) ** beta), 1e-5, 1.0 - 1e-5)
        return finite_logit(f)

    def two_phase_resid(p):
        return (y - two_phase_prediction(p)) / err

    two = least_squares(
        two_phase_resid,
        x0=np.array([0.0, np.log(80.0), np.log(100.0), np.log(0.5)]),
        bounds=([-4.0, np.log(10.0), np.log(30.0), np.log(0.02)], [4.0, np.log(400.0), np.log(400.0), np.log(5.0)]),
    )
    ll_two = weighted_loglike(y, two_phase_prediction(two.x), err)
    n = len(df)
    bic_power = 2 * np.log(n) - 2 * ll_power
    bic_two = 4 * np.log(n) - 2 * ll_two
    return {
        "loglike_power": ll_power,
        "loglike_two_phase": ll_two,
        "bic_power": float(bic_power),
        "bic_two_phase": float(bic_two),
        "delta_lnZ_bic_two_minus_power": float(-0.5 * (bic_two - bic_power)),
        "least_squares_t_break_Myr": float(np.exp(two.x[2])),
    }


def summarize_samples(samples: dict[str, np.ndarray]) -> pd.DataFrame:
    rows = []
    for name, values in samples.items():
        arr = np.asarray(values, dtype=float)
        if arr.ndim != 1:
            continue
        rows.append(
            {
                "parameter": name,
                "p16": float(np.percentile(arr, 16)),
                "p50": float(np.percentile(arr, 50)),
                "p84": float(np.percentile(arr, 84)),
                "mean": float(np.mean(arr)),
                "sd": float(np.std(arr, ddof=1)),
            }
        )
    return pd.DataFrame(rows).sort_values("parameter")


def make_scheme_v2_figure(
    df: pd.DataFrame,
    samples: dict[str, np.ndarray],
    diagnostic: dict[str, float],
    outdir: Path,
) -> None:
    age_grid = np.logspace(np.log10(df["age_Myr"].min() * 0.8), np.log10(df["age_Myr"].max() * 1.2), 240)
    curves = posterior_curves(samples, age_grid)
    q16, q50, q84 = np.percentile(curves, [16, 50, 84], axis=0)
    clean = df["p_good_v2"] > 0.7

    fig, axes = plt.subplots(2, 2, figsize=(11, 8.5), constrained_layout=True)
    ax = axes[0, 0]
    ax.scatter(df["age_Myr"], df["f_L_raw"], s=24, c="0.55", alpha=0.75, edgecolor="none")
    ax.axhline(1.0, color="firebrick", lw=1.0, ls="--")
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlabel("Age (Myr)")
    ax.set_ylabel(r"Raw $J_{\rm int}/J_{\rm virial}$")
    ax.set_title("A. Raw diagnostic")

    ax = axes[0, 1]
    sc = ax.scatter(
        df.loc[clean, "age_Myr"],
        df.loc[clean, "f_L_v2"],
        c=df.loc[clean, "R_GC_kpc"],
        s=34,
        cmap="viridis",
        edgecolor="none",
    )
    ax.scatter(df.loc[~clean, "age_Myr"], df.loc[~clean, "f_L_v2"], s=18, c="0.8", edgecolor="none", alpha=0.65)
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlabel("Age (Myr)")
    ax.set_ylabel(r"Bounded $f_L$")
    ax.set_title(r"B. Cleaned population, $P({\rm good})>0.7$")
    cbar = fig.colorbar(sc, ax=ax)
    cbar.set_label(r"$R_{\rm GC}$ (kpc)")

    ax = axes[1, 0]
    ax.fill_between(age_grid, q16, q84, color="steelblue", alpha=0.24, lw=0)
    ax.plot(age_grid, q50, color="steelblue", lw=2.0)
    ax.scatter(df["age_Myr"], df["f_L_v2"], s=18, c=df["p_good_v2"], cmap="magma", edgecolor="none")
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlabel("Age (Myr)")
    ax.set_ylabel(r"$f_L$")
    ax.set_title("C. Posterior predictive sequence")

    ax = axes[1, 1]
    tb = samples["t_break_Myr"]
    ax.hist(tb, bins=28, color="0.35", alpha=0.85)
    ax.axvline(np.percentile(tb, 50), color="firebrick", lw=2)
    ax.set_xlabel(r"Transition age $t_b$ (Myr)")
    ax.set_ylabel("Posterior samples")
    ax.set_title("D. Two-phase transition diagnostic")
    text = (
        rf"$t_b={np.percentile(tb, 50):.0f}^{{+{np.percentile(tb, 84)-np.percentile(tb, 50):.0f}}}"
        rf"_{{-{np.percentile(tb, 50)-np.percentile(tb, 16):.0f}}}$ Myr"
        "\n"
        rf"$\Delta\ln Z_{{\rm BIC}}\approx {diagnostic['delta_lnZ_bic_two_minus_power']:.1f}$"
    )
    ax.text(0.04, 0.96, text, transform=ax.transAxes, va="top", ha="left", fontsize=11)

    fig.savefig(outdir / "scheme_v2_figure1_two_phase.png", dpi=240)
    plt.close(fig)


def write_summary(
    df: pd.DataFrame,
    posterior: pd.DataFrame,
    diagnostic: dict[str, float],
    outdir: Path,
) -> None:
    def row(name: str) -> pd.Series:
        match = posterior[posterior["parameter"] == name]
        if match.empty:
            return pd.Series({"p16": np.nan, "p50": np.nan, "p84": np.nan})
        return match.iloc[0]

    tau = row("tau_gas_Myr")
    tb = row("t_break_Myr")
    beta = row("beta_eff_at_mean_env")
    beta_rgc = row("beta_r_gc")
    pgood = row("p_good")
    clean_n = int((df["p_good_v2"] > 0.7).sum())
    lines = [
        "# Scheme v2 Two-Phase Despinning Summary",
        "",
        f"Input fitted clusters: {len(df)}",
        f"Cleaned population P(good)>0.7: {clean_n}",
        f"Virial-excess raw f_L>=1 objects: {int(df['is_virial_excess'].sum())}",
        "",
        "## Posterior medians",
        "",
        f"Early despinning timescale tau_gas = {tau.p50:.2f} (+{tau.p84 - tau.p50:.2f}/-{tau.p50 - tau.p16:.2f}) Myr",
        f"Transition age t_b = {tb.p50:.2f} (+{tb.p84 - tb.p50:.2f}/-{tb.p50 - tb.p16:.2f}) Myr",
        f"Late-phase beta at mean environment = {beta.p50:.3f} (+{beta.p84 - beta.p50:.3f}/-{beta.p50 - beta.p16:.3f})",
        f"Environment coefficient beta_r_gc = {beta_rgc.p50:.3f} (+{beta_rgc.p84 - beta_rgc.p50:.3f}/-{beta_rgc.p50 - beta_rgc.p16:.3f})",
        f"Global good-population fraction = {pgood.p50:.3f}",
        "",
        "## Model comparison",
        "",
        f"BIC-approx Delta lnZ(two-phase - single power law) = {diagnostic['delta_lnZ_bic_two_minus_power']:.3f}",
        f"Least-squares transition age check = {diagnostic['least_squares_t_break_Myr']:.2f} Myr",
        "",
        "## Interpretation guardrail",
        "",
        "The v2 model implements the two-phase claim as a testable population model.",
        "A positive Delta lnZ_BIC favors the two-phase curve over a single power law;",
        "a negative value means the current Gaia-only measurements do not yet support",
        "the stronger ApJL claim without additional systematics or RV augmentation.",
    ]
    (outdir / "scheme_v2_summary.md").write_text("\n".join(lines) + "\n")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=Path("outputs/cluster_spin_results.csv"))
    parser.add_argument("--clusters", type=Path, default=Path("hunt24/clusters.dat"))
    parser.add_argument("--outdir", type=Path, default=Path("outputs_v2"))
    parser.add_argument("--warmup", type=int, default=800)
    parser.add_argument("--samples", type=int, default=1000)
    parser.add_argument("--seed", type=int, default=20260619)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)

    df = prepare_v2_data(args.results, args.clusters)
    samples = run_numpyro_model(df, warmup=args.warmup, samples=args.samples, seed=args.seed)
    df["p_good_v2"] = posterior_good_probabilities(df, samples)
    posterior = summarize_samples(samples)
    diagnostic = bic_transition_diagnostic(df)

    df.to_csv(args.outdir / "scheme_v2_cluster_population.csv", index=False)
    posterior.to_csv(args.outdir / "scheme_v2_posterior_summary.csv", index=False)
    pd.DataFrame([diagnostic]).to_csv(args.outdir / "scheme_v2_model_comparison.csv", index=False)
    make_scheme_v2_figure(df, samples, diagnostic, args.outdir)
    write_summary(df, posterior, diagnostic, args.outdir)

    tb = posterior.loc[posterior["parameter"] == "t_break_Myr"].iloc[0]
    tau = posterior.loc[posterior["parameter"] == "tau_gas_Myr"].iloc[0]
    print(f"Scheme v2 fitted clusters: {len(df)}")
    print(f"Clean P(good)>0.7: {(df['p_good_v2'] > 0.7).sum()}")
    print(f"tau_gas median: {tau.p50:.2f} Myr")
    print(f"t_break median: {tb.p50:.2f} Myr")
    print(f"Delta lnZ_BIC two-phase - power law: {diagnostic['delta_lnZ_bic_two_minus_power']:.3f}")
    print(f"Wrote outputs to {args.outdir}")


if __name__ == "__main__":
    main()
