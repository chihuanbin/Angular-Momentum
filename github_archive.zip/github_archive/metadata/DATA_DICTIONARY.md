# R1 data dictionary and provenance map

The CSV headers are preserved from the frozen analysis products. Units below
describe the central fields used by the population inference; the complete
column names remain available in each CSV header.

| File | Key fields | Meaning / units |
|---|---|---|
| `outputs_v3/cluster_population.csv` | `ID`, `Name` | Cluster identifier and name |
|  | `logAge50`, `age_Myr` | Catalogue median age (`log10(t/yr)`) and age in Myr |
|  | `f_L`, `f_L_raw`, `f_L_v2` | Continuous internal angular-momentum proxy variants |
|  | `logit_f_L`, `logit_f_L_err` | Primary transformed response and bootstrap error |
|  | `R_GC_kpc`, `abs_Z_kpc`, `p_good_v3` | Present-day descriptors and quality probability |
| `outputs_environment_regulation/unified_cluster_catalog.csv` | `angular_momentum_diversity_logit_fL`, `..._err` | Unified response and uncertainty used for predictive checks |
|  | `mass_Msun`, `radius_pc`, `R_GC_kpc`, `abs_Z_kpc` | Tested present-day environment and structural covariates |
| `results/r1/age_width_model_comparison.csv` | `model`, `BIC`, `sigma_int`, `slope` | Mean-shape and residual-width comparison |
| `results/r1/constant_vs_age_model.csv` | `intercept`, `slope`, `sigma_int`, `logL_max`, `BIC` | Constant/no-age and simple age-mean null comparison |
| `results/r1/constant_vs_age_cv.csv` | `held_out_RMSE`, `held_out_R2` | Existing repeated-fold predictive comparison |
| `results/r1/age_slope_summary.csv` | `slope_b`, interval fields, `delta_BIC_constant_minus_age` | Age-slope summary and uncertainty |
| `outputs_independent_validation_sampling/sampling_consistency_result_table.csv` | `survey`, `coverage_95`, `external_sigma_int` | Matched external-RV benchmark summary |

Missing values are represented as empty CSV fields unless a source file states
otherwise. The primary fitting coordinate is `log10(t/yr)`; reader-facing
figures display `log10(age/Myr)` after the documented six-dex shift.

## Source and access notes

- `hunt24/clusters.dat` and `hunt24/ReadMe` are the compact Hunt--Reffert
  catalogue component retained here. The member-star table is intentionally
  not mirrored.
- `external_rv_data/provenance.json` records the VizieR catalogue identifiers,
  quality filters, query date, and the local LAMOST source-table note.
- The external CSVs are matched/processed products, not raw survey archives.
  Consult the cited catalogue records for original release terms.
