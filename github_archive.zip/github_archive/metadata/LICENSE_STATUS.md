# Licence status

No public licence is asserted by this archive yet.

Before public release, the authors should add an approved software licence for
the original code and an explicit data/derived-products policy. The upstream
Hunt--Reffert, Gaia, APOGEE, GALAH, and LAMOST catalogue material remains
subject to its original provider terms and must not be relicensed by this
repository. The absence of a licence means that GitHub access does not itself
grant permission to redistribute or reuse every archived file.
