# Novelty matrix

| previous work | sample scale | observable | main question | selection treatment | external validation | what this paper adds |
|---|---|---|---|---|---|---|
| Soubiran et al. (2018) | Gaia DR2 open-cluster population | cluster kinematics and ages | How are cluster kinematics distributed and ordered in the Galaxy? | catalogue-specific Gaia selection | none at this population level | tests whether an internal angular-momentum proxy is a narrow age sequence rather than only an age-correlated quantity |
| Tarricq et al. (2021) | Gaia-era open-cluster population | 3D cluster kinematics and age distribution | How do cluster motions and ages populate the Galactic disc? | survey/sample selection, not this RV-gradient forward test | none at this population level | separates conditional-mean age shape from residual width for an internal dynamical proxy |
| Godoy-Rivera et al. (2021) | individual stars in open clusters | stellar rotation periods | How do stellar rotation sequences evolve with age? | stellar-period completeness | none at this population level | addresses cluster internal angular momentum, not stellar spin, and tests a population-level age-clock hypothesis |
| Hunt & Reffert (2024) | Gaia DR3 cluster catalogue | membership, masses, radii, dynamics | How can a clean cluster catalogue be constructed? | catalogue quality and membership cuts | catalogue construction | supplies the homogeneous parent population used for the inference |
| Wright et al. (2026) | individual cluster NGC 2516 | 3D internal rotation | What is the internal rotation state of one cluster? | cluster-level RV/astrometric sampling | cluster-level evidence | extends the question from individual systems to population width and identifiability |

The specific contribution is not a claim of priority. It is the evidentiary decomposition: (i) mean age dependence, (ii) explicit falsification of a narrow deterministic age clock, (iii) incremental present-day predictors, (iv) a calibrated Gaia-RV selection sufficiency experiment, (v) synthetic estimator/population identifiability, and (vi) sampling-matched LAMOST validation.

