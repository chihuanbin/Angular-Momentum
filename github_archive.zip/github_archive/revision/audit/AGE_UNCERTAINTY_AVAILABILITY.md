# Age-uncertainty availability audit

## Source inspection

The primary cluster source is `hunt24/clusters.dat`, documented by its local
`ReadMe`.  The catalogue provides `logAge16`, `logAge50`, and `logAge84` for
the selected clusters.  The existing merged table
`outputs_environment_regulation/unified_cluster_catalog.csv` contains the
same information as `age_Myr`, `age_Myr_err_minus`, and
`age_Myr_err_plus`.

For the 125-cluster fitted population:

| quantity | result |
|---|---:|
| clusters with finite central age | 125 |
| clusters with finite lower/upper age quantiles | 125 |
| non-positive lower/upper interval widths | 0 |
| clusters with `age - err_minus <= 0` | 0 |
| median half-width in log10(age) | 0.223 dex |

The catalogue therefore supports a primary age-error sensitivity.  No
posterior samples for the catalogue ages are distributed, so the revision
does not claim a full catalogue posterior.  Instead it samples latent
`x_true` values from a fixed normal approximation in log-age whose scale is
the catalogue half-width, with the asymmetric quantiles retained in the
machine-readable source columns.

## R1 treatment

For every Monte Carlo draw, `x_true` is sampled per cluster and the single,
broken, and fixed-regularization flexible mean relations are refit with

\[
 y_i\sim {\cal N}\!\left(\mu(x_{\rm true,i}),
 \sqrt{\sigma_{y,i}^2+\sigma_{\rm int}^2}\right).
\]

The central fit uses `logAge50`; the uncertainty run uses the fixed random
seed recorded in `provenance/r1_provenance.json`.  This is a sensitivity
integration over the supplied catalogue intervals, not a newly inferred age
posterior.  The resulting comparison is written to
`results/r1/age_uncertainty_sensitivity.csv`.

## Limitation

The Hunt & Reffert quantiles are catalogue-level age summaries and may share
model systematics.  The revision therefore reports the age-error run as
propagation/sensitivity, not as an independent age determination.
