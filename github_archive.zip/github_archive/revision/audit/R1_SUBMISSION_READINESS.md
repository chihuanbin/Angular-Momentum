## A&A R1 SUBMISSION READINESS

Scientific logic: PASS
Motivation and novelty: PASS
Choice of f_L and dynamical scope: PASS
Physical interpretation and mechanism discussion: PASS
Systematics and non-axisymmetric structure: PASS
Narrow-sequence BIC audit: PASS
Age-uncertainty wording: PASS
Transform interpretation: PASS
Environment wording: PASS
Selection wording: PASS
Synthetic analysis: PASS
External validation: PASS
LAMOST citation: PASS
Claim consistency: PASS
Numerical traceability: PASS
Referee response: PASS
Bibliography: PASS
Internal-version cleanup: PASS
Figure/table argument maps: PASS
Figures: PASS
Tables: PASS
Clean LaTeX build: PASS
Marked manuscript: OPTIONAL

SUBMISSION BLOCKERS:
- None.

NON-BLOCKING LIMITATIONS:
- Source-level covariance among membership, structure, normalisation, and RV availability is not available.
- No multi-epoch binary model is present in the supplied catalogue.
- APOGEE and GALAH remain below the pre-defined population threshold.
- A rendered latexdiff PDF was not produced; the clean manuscript and unified source diff are supplied.

FINAL DECISION:
READY FOR R1 RESUBMISSION
