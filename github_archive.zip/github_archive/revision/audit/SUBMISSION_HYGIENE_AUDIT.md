# Submission hygiene audit

| check | status | evidence |
|---|---|---|
| internal-version language | FAIL | hits=2 |
| duplicate labels | PASS | duplicates=[] |
| undefined references | PASS | undefined=[] |
| figure files | PASS | missing=[] |
| figure citations | PASS | uncited=[] |
| table citations | PASS | uncited=[] |
| bibliography keys | PASS | missing=[] |
| uncited bibliography entries | PASS | uncited=[] |
| PDF metadata | PASS | {'Title': 'Gaia DR3 Constraints on Angular-Momentum Diversity in Galactic Open Clusters', 'Subject': 'Open-cluster internal angular momentum and Gaia DR3 radial velocities', 'Keywords': 'open clusters, angular momentum, Gaia DR3, radial velocities', 'Author': 'Jinli Lv and Huanbin Chi', 'Creator': 'LaTeX with hyperref', 'Producer': 'pdfTeX-1.40.29', 'CreationDate': 'Sat Sep 19 11:31:07 2026 CST', 'ModDate': 'Sat Sep 19 11:31:07 2026 CST', 'Custom Metadata': 'yes', 'Metadata Stream': 'no', 'Tagged': 'no', 'UserProperties': 'no', 'Suspects': 'no', 'Form': 'none', 'JavaScript': 'no', 'Pages': '10', 'Encrypted': 'no', 'Page size': '595.276 x 841.89 pts (A4)', 'Page rot': '0', 'File size': '977870 bytes', 'Optimized': 'no', 'PDF version': '1.7'} |

## Figure and table labels

Figures: fig:architecture, fig:age, fig:robust, fig:hier, fig:selection, fig:synthpair, fig:external; tables: tab:sample, tab:width, tab:environment.

## Hard-coded numbering scan

No hard-coded cross-reference strings were found.

## Internal-language matches

- L107: For display, figures use $x_{i,\rm Myr}=x_i-6=\log_{10}(t_i/{\rm Myr})$. This additive shift leaves slopes, model ordering, spline shape, and age-uncertainty perturbations unchanged; only the intercept changes. The registered predictive Ridge check uses $\log_{10}(t/{\rm Myr})$ directly, and break ages and spline knots are converted to Myr only for display.
- L139: We use one fixed Ridge regression ($\alpha=1$) and identical five-fold, five-repeat splits for three models: age only, environment only, and age plus environment. The primary metrics are held-out RMSE and $R^2$, with $\Delta R^2$ relative to age only. Environmental descriptors are present-day catalogue quantities or deterministic proxies; failure to predict does not imply that formation environment has no physical effect. Feature definitions, scaling, and missingness are provided with the machine-readable tables. The population analysis treats $\fl$ as a continuous estimator response, not as a binary cluster-by-cluster rotation-detection statistic.

The clean submission directory contains only the manuscript source, bibliography, required class/style files, and figures; auxiliary build products are excluded.
