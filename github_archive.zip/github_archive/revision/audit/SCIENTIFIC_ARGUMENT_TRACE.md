# Scientific argument trace

| claim | result subsection | figure/table | physical interpretation | systematic affecting it | discussion subsection | conclusion sentence |
|---|---|---|---|---|---|---|
| Age is the strongest compact predictor among tested observables | 3.1, 3.2 | Fig. 2; Table 3 | age contains dynamical information about the conditional mean | age uncertainty, selection, present-day descriptors | 4.1--4.3 | “age organizes the conditional mean” |
| A simple age dependence is adequate for the mean | 3.1 | Fig. 2; Table 2 | no discrete transition is required at current precision | age uncertainty and transform | 4.1 | “data do not require a broken or two-phase age relation” |
| A narrow deterministic age-only sequence is strongly disfavoured | 3.1 | Fig. 3; Table 2 | age is not a sufficient one-parameter dynamical clock | quoted errors, transform, finite sampling | 4.1; 4.3 | “a narrow deterministic age-only description is strongly disfavoured” |
| Broad residual population width remains | 3.1 | Fig. 2; Table 2 | comparable-age clusters occupy heterogeneous present-day states | selection, binaries, covariance, membership | 4.2--4.3 | “substantial cluster-to-cluster intrinsic scatter remains” |
| Flexible mean modelling does not absorb the width | 3.1 | Fig. 3; Table 2 | width is not explained by an overly rigid mean curve | spline regularization and transform | 4.1 | “greater flexibility does not absorb this width” |
| Present-day environment adds no held-out information | 3.2 | Table 3 | no compact second coordinate is found among tested descriptors | descriptors do not encode formation/tidal history | 4.1; 4.3 | “descriptors do not improve out-of-sample prediction” |
| Severe RV incompleteness is sufficient for comparable scatter | 3.3 | Fig. 5 | selection can broaden the measured population at observed order | unobserved stars absent from Gaia | 4.3 | “selection is sufficient to generate comparable scatter” |
| Smooth populations rarely yield a strong break | 3.3 | Figs. 6--7 | estimator/model chain does not commonly manufacture a break | scenario grid and recovery criterion | 4.3 | “synthetic tests quantify false-break rates” |
| LAMOST supports the population-level result after matching | 3.3 | Fig. 7 | changing RV source does not erase broad width/model ordering | sub-nominal cluster coverage and sparse external samples | 4.4 | “the sampling-matched LAMOST comparison supports the population-level width and model-ordering conclusions” |
| Physical decomposition remains unresolved | 3.3 | Fig. 5; Fig. 7 | observations do not separate intrinsic and selection broadening | binaries, covariance, history, missing RVs | 4.2--4.4 | “the physical contribution ... is not uniquely identified” |
