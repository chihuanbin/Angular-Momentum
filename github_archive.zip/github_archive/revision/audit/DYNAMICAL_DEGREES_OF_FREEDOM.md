# Dynamical degrees of freedom audit

The population analysis is intentionally centred on the antisymmetric part of the fitted first-order internal velocity-gradient tensor. The source population product contains several related quantities, but their availability does not by itself establish comparable measurement stability or a calibrated selection model.

| quantity | available? | measurement stable? | physical meaning | independent of $f_L$? | suitable for current paper? | reason included/excluded |
|---|---|---|---|---|---|---|
| $\omega_x,\omega_y,\omega_z$ | yes (125/125) | component values are available; component-level uncertainty products are not used in the population fit | orientation and signed local angular velocity | partly | no additional headline | the scalar mass-scaled proxy is the calibrated population observable |
| $|\boldsymbol\omega|$ / vorticity norm | yes (125/125) | derived from the same gradient and shares its finite-sampling and non-rotational-gradient biases | amplitude of the antisymmetric velocity field | yes, but not orthogonal to $f_L$ | no | would repeat the same estimator without a separate population calibration |
| spin-axis orientation | yes (125/125) | point estimates are available, but no orientation likelihood or selection calibration is supplied | direction of the local rotational component | yes | no | orientation has a distinct spherical selection problem beyond this paper's scalar population test |
| symmetric-gradient amplitude (strain) | yes (125/125) | a point estimate exists, but no propagated uncertainty or dedicated null/recovery calibration is available | expansion/contraction and shear | yes | no | a control analysis would require its own estimator and RV-selection model |
| velocity dispersion $\sigma_{1\rm D}$ / $\sigma_{3\rm D}$ | yes (125/125) | used as a scale in $f_L$; not an independent calibrated response here | random kinetic support | not fully, because $\sigma_{3\rm D}$ enters the denominator | no | treating it as a second response would reuse a defining quantity and invite circular interpretation |
| dispersion anisotropy | no complete product | no | directional structure of random motions | yes | no | not recoverable as a consistently calibrated population observable from the supplied products |
| higher-order velocity structure | no | no | non-linear rotation, substructure, or localized streaming | yes | no | requires a separate model and completeness experiment |

The pipeline therefore already exposes orthogonal tensor ingredients, but only the antisymmetric, mass-scaled scalar has the uncertainty and population-model products used here. Adding an uncalibrated companion observable would not resolve the single-dynamical-variable criticism; it would mix quantities with different selection functions. The manuscript states this scope choice explicitly and identifies symmetric expansion/shear, anisotropy, orientation, and higher-order structure as follow-up observables.

