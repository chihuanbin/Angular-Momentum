# Age-variable unit audit

## Decision

The frozen likelihood keeps the internal fitting variable

\[
x_{\rm yr}=\log_{10}(t/{\rm yr}).
\]

Figures and reader-facing tables display

\[
x_{\rm Myr}=\log_{10}(t/{\rm Myr})=x_{\rm yr}-6.
\]

The conversion is an additive shift of exactly six dex. Therefore slopes,
profile likelihoods, spline shapes, age-error draws, and model ordering are
unchanged. A linear-model intercept reported at the Myr coordinate is related
to an intercept at the yr coordinate by the corresponding additive $6b$
shift. Constant-model intercepts are unit-invariant.

## Script and figure inventory

| Component | Internal unit | Display/output unit | Conversion | Audit result |
|---|---|---|---|---|
| `analysis/r1_age_inference.py` | `x50 = log10(age_Myr)+6`, equivalent to `log10(age/yr)` | `age_Myr` in prediction table and `log10(age/Myr)` in plots | `CONV=log10(1e6)`; subtract six for display | consistent |
| `analysis/r1_constant_age_null.py` | `x_internal=log10(age/yr)`; age-model intercept parameterised at `log10(age/Myr)` | `x_display=log10(age/Myr)` for CV and reported slope | `x_display=x_internal-6` | consistent; constant/no-age fit uses the same rows and likelihood |
| `analysis/r1_narrow_sequence_bic_audit.py` | `x=log10(age/yr)`; prediction uses `x-CONV` | no plotted age coordinate | subtract six in the linear predictor | consistent with frozen narrow-width audit |
| `analysis/r1_environment_prediction.py` | `log_age_Myr=log10(age_Myr)` | same `log10(age/Myr)` feature | no shift required because the feature is already in Myr | consistent; this is the registered predictive CV feature |
| `analysis/r1_synthetic_identifiability.py` | `log10(age/100 Myr)` | scenario configuration reports break age in Myr | divide age by 100 Myr before log; break uses `log10(break_age_Myr/100)` | consistent within the synthetic scenario parameterisation |
| `analysis/r1_plots.py`, Fig. 2 | reads `age_Myr` and plots `log10(age_Myr)` | `log10(age/Myr)` | direct | consistent |
| `analysis/r1_plots.py`, Fig. 4 | reads `age_Myr` and plots `log10(age_Myr)` | `log10(age/Myr)` | direct | consistent |
| `analysis/r1_plots.py`, manuscript Fig. 7 (source file `figure8_lamost_validation`) | reads `age_Myr` and plots `log10(age_Myr)` | `log10(age/Myr)` | direct | consistent |
| manuscript equations and captions | likelihood notation explicitly uses `log10(t/yr)` | figures explicitly use `log10(age/Myr)` | six-dex additive shift stated in Sect. 2.3 | corrected and explicit |

## Knots, breaks, and age-error draws

The five spline knots are generated from the internal `x50` values and are
converted to `age_Myr` only in `flexible_age_predictions.csv`. Broken-model
searches use the internal yr-coordinate grid and report `break_age_Myr` after
subtracting six dex before exponentiation. Catalogue age-error draws perturb
the internal log-age coordinate, so the same draws would result under the
Myr display coordinate. The reported single-model slope is per dex in either
coordinate; only the intercept changes under the additive shift.

No silent mixing of yr and Myr remains in the revised manuscript, the new
constant/no-age analysis, or the figure-generation paths.
