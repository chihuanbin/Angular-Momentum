# R1 logic audit

## Scope and frozen baseline

The audit covers the submitted source at `latex_Angular-Momentum/main.tex`,
its bibliography, the local Hunt & Reffert catalogue (`hunt24/`), the fitted
population table (`outputs_v3/cluster_population.csv`), and the existing
analysis products under `outputs_*`.  The source repository is not a Git
checkout (`git rev-parse HEAD` fails), so provenance uses file hashes and the
recorded command/date instead of a commit hash.  Original files are retained;
all R1 products are written under `revision/`, `analysis/r1/`, and
`results/r1/`.

## Current inferential claims and evidence

| Current claim | Evidence in submitted manuscript | Logical status at audit |
|---|---|---|
| A single age trend has the lowest BIC | Table `tab:model`; `outputs_v3/model_comparison.csv` | Supported as a mean-relation comparison, not evidence for a narrow sequence |
| A universal age-only sequence is not supported | Same BIC table plus fitted intrinsic scatter | Incomplete: the manuscript did not explicitly compare `sigma_int=0` with `sigma_int>0` under identical assumptions |
| The population has broad residual diversity | `sigma_int` estimates from marginal and hierarchical fits | Requires an explicit narrow-sequence likelihood test and a transformation/age-error audit |
| Age is the strongest compact predictor | `outputs_environment_regulation/*`, BIC and cross-validation | Model-shopping risk: many secondary diagnostics and model families obscure the primary out-of-sample question |
| Environment does not matter | Environmental BIC/diagnostic suite | Overclaim. The evidence concerns only tested present-day catalogue descriptors |
| RV incompleteness can produce observed scatter | `outputs_selection_function_mc/selection_mc_summary.csv` | Supported as sufficiency, not attribution; the selection-only null samples only stars already present in Gaia |
| Synthetic recovery rules out estimator-induced broken relations | `outputs_synthetic_cluster_recovery/population_simulation_summary.csv` | Partial. Existing run tests a smooth synthetic population but not the requested frozen S0--S3 identifiability/power scenarios |
| Hierarchical model independently confirms the population result | `outputs_hierarchical_bayes/*` | Incorrect framing. The latent Gaussian hierarchy marginalises to the same intrinsic-scatter likelihood |
| External surveys validate the population | `outputs_independent_validation_sampling/*` | Only LAMOST reaches the preregistered 12-cluster threshold; APOGEE/GALAH are cluster-level diagnostics |
| `f_L` behaves as a bounded fraction | logit transform after clipping in methods | Inconsistent with the stated definition as a normalized proxy; 11 raw values are `f_L>=1` |

## Required hypothesis separation

Let `x=log10(age/yr)` and `y=logit(f_L)` for the registered baseline
transform.  The population model is

\[
 y_i \sim {\cal N}\!\left[\mu(x_i),
 \sqrt{\sigma_{y,i}^2+\sigma_{\rm int}^2}\right].
\]

The revision treats four hypotheses as distinct:

* **H_mean:** which functional form is required for `mu(x)` (single, broken,
  or the fixed-regularization flexible benchmark)?
* **H_width:** is `sigma_int` consistent with zero, or is positive residual
  population width required after measurement error?
* **H_env:** do the tested present-day descriptors improve held-out prediction
  after age is included?
* **H_selection:** can the RV sampling and estimator generate a population
  structure of the observed scale?

The key conceptual correction is:

> “single age trend is BIC-preferred” is a statement about the shape of the
> conditional mean.  It is not equivalent to “age defines a universal narrow
> sequence.”

## Audit findings and revision actions

1. Add an explicit `sigma_int=0` versus `sigma_int>0` comparison and a
   machine-readable table (`results/r1/age_width_model_comparison.csv`).
2. Add a fixed, regularized spline benchmark as a model-specification check,
   not as a new physical scenario.
3. Use the catalogue `logAge16/logAge50/logAge84` values.  These are available
   for all 125 fitted clusters, so age-error propagation is feasible and is
   not blocked.  The asymmetric catalogue intervals are represented in
   log-age by the corresponding half-width for a Monte Carlo latent-age
   sensitivity.
4. Refit the same population under `logit(f_L)` and `log(f_L)` using raw
   positive `f_L`; report the 11 upper-bound cases and any changed inference.
5. Replace the environmental diagnostic collection in the main narrative with
   fixed-fold age-only, environment-only, and age-plus-environment prediction.
6. Freeze S0--S3 before executing the synthetic identifiability extension.
7. Audit the non-monotonic recovery efficiency by decomposing completeness,
   case composition, detection criterion, and normalized error scale.
8. Recast hierarchical results as latent-cluster estimates and uncertainty,
   not independent evidence for model preference.
9. Verify LAMOST provenance from the local DR11 fixed-width table and its
   VizieR identifier; do not substitute the GALAH citation.
10. Replace the sequential-method flowchart with an inference architecture
    that separates mean shape, residual width, added predictors, and the three
    observational credibility checks.

## Blockers identified before R1 execution

No raw-data blocker was found: raw positive `f_L` values and catalogue age
quantiles are present locally.  A repository commit hash is unavailable
because the workspace is not a Git checkout.  External-survey bibliography
entries for LAMOST/APOGEE/GALAH are not present in `ref.bib`; the R1 audit must
therefore add only provenance-supported entries or mark citation verification
required rather than inventing a citation.
