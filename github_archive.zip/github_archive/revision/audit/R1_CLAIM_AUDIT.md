# R1 claim-preservation audit

The complete manuscript and referee response were scanned case-insensitively for the required claim terms: universal, reject, rejected, prove, proves, demonstrate, demonstrates, intrinsic, physical, origin, environment, causal, cause, selection, robust, independent, validate, validation, age-only, deterministic, narrow, sequence, scatter. Each substantive hit was classified by context; the claim ledger records the major claims and recommended wording.

**Status: PASS** — 86 term-bearing lines scanned; 0 unqualified physical/causal overclaims.

## Preserved hierarchy

1. The age-dependent mean is preferred over the constant mean among the tested population descriptions.
2. Additional broken or two-phase structure is not required for the conditional mean.
3. A narrow deterministic age-only sequence is strongly disfavoured under the adopted measurement model.
4. Broad residual width remains and is not absorbed by the flexible mean benchmark, clean subset, age-interval sensitivity, or logarithmic transform.
5. Tested present-day descriptors do not improve out-of-sample prediction beyond age.
6. Severe RV incompleteness is sufficient to generate comparable apparent scatter.
7. LAMOST supports the population-level width and model ordering after sampling matching, with sub-nominal cluster-level coverage.
8. The physical origin/fraction of the width remains unresolved.

## Unqualified overclaim scan

None found. Phrases such as `reject`, `intrinsic scatter`, `selection-induced`, and `physical origin` occur only with the statistical/model qualifier or an explicit limitation.

## Classification summary

- STATISTICAL or MODEL-CONDITIONAL INFERENCE: 30 lines
- PHYSICAL INTERPRETATION / SPECULATION: 20 lines
- OBSERVATION / METHODS: 36 lines

The full term-bearing lines remain in the generated final audit for traceability; they are not treated as overclaims solely because a strong statistical word appears.
