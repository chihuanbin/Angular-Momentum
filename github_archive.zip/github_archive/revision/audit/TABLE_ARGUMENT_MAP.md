# Table argument map

| table | question answered | first citation | main takeaway | redundant? |
|---|---|---|---|---|
| Table 1 (`tab:sample`) | Which Gaia cluster population is being inferred? | Data and inference, Sect. 2.1 | 133 clusters enter the cuts, 125 gradients are fitted, and 114 form the pre-existing high-quality subset. | no; defines sample scope |
| Table 2 (`tab:width`) | Does the mean-shape choice differ from the residual-width question? | Results, Sect. 3.1 | The simple relation is adequate for the mean, while the zero-width sequence is strongly disfavoured and the flexible benchmark leaves comparable width. | no; separates H_mean and H_width |
| Table 3 (`tab:environment`) | Do present-day descriptors improve prediction beyond age? | Results, Sect. 3.2 | Age plus environment does not improve held-out prediction ($\Delta R^2=-0.027$). | no; reports the primary predictive comparison |

Each table is cited before or at first display and its scientific conclusion is stated in the surrounding prose. Secondary diagnostics remain in machine-readable supplementary material rather than duplicating these compact tables.

