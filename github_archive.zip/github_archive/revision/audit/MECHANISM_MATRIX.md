# Physical mechanism matrix

| mechanism | qualitative effect on ordered motion | direct diagnostic in current data | distinguishable here? |
|---|---|---|---|
| formation angular momentum / primordial substructure | sets initial amplitude, orientation, or local coherence | present-day $f_L$ only | no |
| early gas expulsion | can expand, torque, or erase coherent motion | structural and age descriptors, no gas history | no |
| two-body relaxation | redistributes and generally evolves ordered motion | age and present-day dispersion only | no |
| mass segregation / tracer-mass selection | changes which stellar population supplies the RV gradient | membership and magnitude matching | not uniquely |
| binary orbital contamination / binary heating | perturbs individual RVs and can inject kinetic energy | single-epoch quality cuts; no uniform multi-epoch model | no |
| Galactic tides | torques, strips, or reshapes the cluster | present position and coarse descriptors | no full history |
| spiral-arm/bar perturbations | time-dependent forcing and reorientation | no orbit-history calculation | no |
| molecular-cloud encounters | impulsive heating or tidal distortion | no encounter catalogue | no |
| dissolution / escaper contamination | broadens non-equilibrium velocity structure | membership and radius cuts | no |

These are physically distinct routes to the same statistical population width. The current data identify broad present-day heterogeneity but do not identify a dominant channel or a unique physical fraction.

