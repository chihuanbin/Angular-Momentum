# Independent narrow-sequence BIC audit

Generated from `analysis/r1_narrow_sequence_bic_audit.py` on 2026-09-17. The
script re-reads `outputs_v3/cluster_population.csv` and implements the same
single-mean Gaussian likelihood without importing the registered fitting
module. Inputs are never modified.

## Identical data and likelihood

The positive-scatter and fixed-zero fits use the same sorted rows, ages,
response values, uncertainty values, transform, and likelihood normalization.
For the baseline logit fit, `N=125`, row SHA-256 is
`4c66c1d1a9720f901979cf8529e2aefe3d38aa3f716ca1a2849661e50446724c`, and the
ID SHA-256 is `03bc59db53e4d11c5d75bee533ff3a7c9ff68056d51d2f653fbcb48608a3d008`;
the hashes are identical for both paired models. The clean-sample hashes are
also identical within each pair. The log transform uses the same 125 positive
raw values and the same lower error treatment as the registered robustness
script.

## Independent BIC recomputation

For every row below, `BIC = k ln(N) - 2 log L_max`; no optimizer-stored BIC is
used. The complete machine-readable table is
`results/r1/narrow_sequence_bic_audit.csv`.

| dataset | transform | model | N | k | log L_max | k ln(N) | -2 log L | BIC | Delta BIC (zero - positive) |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| baseline | logit(f_L) | sigma_int > 0 | 125 | 3 | -322.668826 | 14.484941 | 645.337653 | 659.822594 | 2551.581673 |
| baseline | logit(f_L) | sigma_int = 0 | 125 | 2 | -1600.873820 | 9.656627 | 3201.747640 | 3211.404267 | 2551.581673 |
| baseline | log(f_L) | sigma_int > 0 | 125 | 3 | -202.634030 | 14.484941 | 405.268059 | 419.753000 | 386.381421 |
| baseline | log(f_L) | sigma_int = 0 | 125 | 2 | -398.238897 | 9.656627 | 796.477794 | 806.134421 | 386.381421 |
| clean, P(good)>0.7 | logit(f_L) | sigma_int > 0 | 114 | 3 | -188.207116 | 14.208595 | 376.414233 | 390.622828 | 80.618236 |
| clean, P(good)>0.7 | logit(f_L) | sigma_int = 0 | 114 | 2 | -230.884333 | 9.472397 | 461.768667 | 471.241064 | 80.618236 |
| clean, P(good)>0.7 | log(f_L) | sigma_int > 0 | 114 | 3 | -168.436658 | 14.208595 | 336.873317 | 351.081912 | 195.763818 |
| clean, P(good)>0.7 | log(f_L) | sigma_int = 0 | 114 | 2 | -268.686666 | 9.472397 | 537.373333 | 546.845730 | 195.763818 |

The registered value `Delta BIC=2551.581673` is therefore independently
reproduced. The clean pre-existing `P(good)>0.7` sample retains the same
conclusion (`Delta BIC=80.618236`). Removing the upper logit boundary also
retains the conclusion (`Delta BIC=386.381421`), so rejection of a narrow
sequence is not specific to the bounded transform.

## Likelihood contributions and residuals

`results/r1/narrow_sequence_residuals.csv` contains the required per-cluster
contributions for the baseline logit sigma_int=0 fit. The absolute
standardized-residual summaries are median `1.764`, 90th percentile `5.211`,
95th percentile `7.405`, and maximum `20.832`; the contribution sum is
`-1600.873820`, matching the independent log likelihood. The likelihood
improvement over the positive-scatter fit is positive for 63 clusters. The
largest six contributions are NGC_6705 (418.81), Ruprecht_91 (409.40), HSC_655
(347.40), NGC_7044 (302.15), HSC_650 (286.47), and NGC_1245 (277.58) in
`-2 Delta log L` units. The largest five account for 69.0% and the largest ten
for 86.4% of the total improvement. Thus the large BIC is population-wide in
the sense that many rows contribute, but it is quantitatively concentrated in
a small set of extreme residuals; it is not a single-row arithmetic artefact.
Several of these values are among the registered upper-clip cases, which is
why the unbounded-log check is reported explicitly.

## Uncertainty-floor and cap check

For `logit_f_L_err` the minimum is 0.359448, the 1st percentile is 0.367846,
the 5th percentile is 0.471282, the median is 0.785239, the 95th percentile
and maximum are both 2.000000. There are zero zero-valued errors and zero
values below 0.01. Twenty rows are at the pre-defined 2.0 cap; 101 distinct
error values occur (26 rows participate in duplicated values). The source code
(`scheme_v2_analysis.py`) applies `np.clip(yerr, 0.25, 2.0)` before writing the
frozen table, and that registered floor/cap is used consistently; no new floor
was introduced for this audit. Tiny uncertainties therefore do not explain
the 2551.6 value through an accidental zero-error term, although the exact
upper-cap cases are part of the transformation sensitivity already reported.

## Interpretation

The result is retained as **strongly disfavoured under the adopted measurement
model**. It is a statistical/model-conditional statement about the narrow
deterministic age-only hypothesis, not an unconditional physical claim. No
informal sigma conversion or naive boundary-variance p-value is used.
