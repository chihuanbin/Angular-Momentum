# Repository inventory used for R1

The original workspace was inspected before edits. No Git metadata are present, so file hashes rather than a commit identifier are recorded in `provenance/r1_provenance.json`.

| component | location inspected | R1 treatment |
|---|---|---|
| submitted manuscript | `latex_Angular-Momentum/main.tex` | preserved; new source under `revision/manuscript/main.tex` |
| bibliography and A&A class | `latex_Angular-Momentum/ref.bib`, `aa.cls`, `aa.bst`, `natbib.sty` | copied; provenance-supported survey entries added only to revision copy |
| accepted cluster population | `outputs_v3/cluster_population.csv` | read-only input; 125 fitted clusters retained |
| source catalogue and age fields | `hunt24/clusters.dat`, `hunt24/ReadMe` | read-only input; logAge16/50/84 inspected |
| existing analysis scripts | `analysis/*.py` | read-only baseline; new R1 scripts under `analysis/r1_*.py` |
| original figures and tables | `figures/`, `outputs_*` | preserved; revised figures under `revision/manuscript/figures/` |
| selection and synthetic products | `outputs_selection_function_mc/`, `outputs_synthetic_cluster_recovery/` | preserved; summarized/audited into `results/r1/` |
| external RV products | `external_rv_data/`, `outputs_independent_validation_sampling/` | preserved; provenance and threshold audit written |
| referee report | `latex_Angular-Momentum/reviewer2_major_revision_report.md` | mapped point-by-point in `revision/response_to_referee.md` |

No raw data, submitted outputs, or source catalogue files were overwritten.
