# External RV provenance audit

| survey | release/catalogue identifier | query/source | RV quality rules | cluster threshold | accepted clusters |
|---|---|---|---|---:|---:|
| APOGEE | DR17; VizieR `III/286/catalog`, `GaiaEDR3`/`HRV` | `external_rv_data/apogee_rv.csv`, source-ID query recorded in `external_rv_data/provenance.json` | finite RV and error, `0<e_RV<10`, catalogue `SFlag` rule | 8 RV members and 12 clusters for population fit | 5 (population fit blocked: below 12) |
| GALAH | DR3; VizieR `J/MNRAS/506/150/stars`, `GaiaEDR3`/`RVgalah` | `external_rv_data/galah_rv.csv`, source-ID query recorded in provenance | finite RV and error, `0<e_RV<10`, `Flagsp` rule | 8 RV members and 12 clusters for population fit | 4 (population fit blocked: below 12) |
| LAMOST | DR11 low-resolution; VizieR `V/162/dr11sl`, `GaiaDR3`/`RV` | local complete fixed-width `external_rv_data/dr11sl.dat`, streamed by `fetch_external_rv_catalogs.py` | finite RV and error, `0<e_RV<10`, `snrg>=10` | 8 RV members and 12 clusters for population fit | 32 accepted; 30 with strict Gaia pool for matched population |

## Crossmatch and estimator

All production matches use Gaia DR3/EDR3 source identifiers.  No positional
fallback is used.  Repeated spectra are inverse-variance combined where the
catalogue supplies repeats; available RV-variable flags are excluded.  The
external calculation uses Gaia astrometry and the external line-of-sight RVs,
then matches Gaia Monte Carlo samples to external tracer count, magnitude, and
projected radius.  The registered seed is 20260707 and the minimum per-cluster
RV threshold is eight.

## Bibliography check

The ingested file is the LAMOST **low-resolution** DR11 A/F/G/K catalogue
`V/162/dr11sl`, not the separate MRS files (`dr11m`, `dr11sm`, or `dr11mem`).
The official CDS ReadMe identifies `V/162` as “LAMOST DR11 catalogs (Luo+,
2026)” and explicitly lists `dr11sl.dat` as the LRS A/F/G/K catalogue.  The
manuscript therefore cites the provenance-supported [VizieR DR11 catalogue
record](https://cdsarc.cds.unistra.fr/viz-bin/ReadMe/V/162?format=html&tex=true)
with BibTeX key `Luo2026LAMOSTDR11`; it does not relabel the data as MRS and
does not invent a journal release paper.  The official DR11 documentation's
MRS method references (Liu et al. 2020, arXiv:2005.07210, and Wang et al.
2019, ApJS, 244, 27) are not cited as data provenance because no MRS table was
ingested.  APOGEE and GALAH retain their own release references, and the
GALAH/Buder citation is not used for LAMOST.

**LAMOST citation: PASS.** Exact catalogue/release provenance is retained in
the manuscript, this audit, and `external_rv_data/provenance.json`.

## Population-level interpretation

Only LAMOST satisfies the preregistered 12-cluster population threshold.
APOGEE and GALAH remain cluster-level/contextual checks and are not promoted
to population evidence.  The machine-readable cluster counts and matched
population quantities are in
`outputs_independent_validation_sampling/sampling_consistency_result_table.csv`.
