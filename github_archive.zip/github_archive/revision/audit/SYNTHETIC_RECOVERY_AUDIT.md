# Synthetic recovery audit

## Question
Why is the registered recovery efficiency non-monotonic with nominal RV completeness, particularly lower at nominal 100%?

## Evidence

The existing design contains 360 cases and two repeats per case.  The nominal completeness groups are unbalanced (73, 66, 101, 68, and 52 design cases for 0.2, 0.4, 0.6, 0.8, and 1.0).  Their rotation-amplitude distributions also differ, with median amplitudes 0.00, 0.05, 0.20, 0.20, and 0.50 km s$^{-1}$.  The physical-scenario composition is not held fixed (see `synthetic_recovery_calibration.csv` and the crosstab below).

The simulator's 1.0 setting is a nominal multiplicative factor on the magnitude-dependent RV probability, not a deterministic all-star RV sample.  The median realised completeness is therefore 0.988, with a range across individual realisations of approximately 0.918--1.000.  Lower settings have median realised completeness 0.200, 0.402, 0.597, and 0.800.

The registered detection criterion is `recovered amplitude >= 0.5 max(injected amplitude, 0.05 km s^-1)`.  It is not invariant to signal regime or non-rotational gradients.  At nominal 100%, the group has a larger fraction of high-amplitude and physical-effect cases, and the recovery bias is negative.  At lower completeness, subsampling adds positive estimator scatter and can satisfy the threshold even when the recovered value is biased.

## Decision
The anomaly is a legitimate design/composition effect, not evidence of an implementation bug in the existing outputs.  No input or original result is modified.  The R1 manuscript reports realised completeness, group composition, the registered criterion, and normalized error metrics, and does not interpret the sequence as a monotonic calibration curve.

## Physical-scenario composition (fraction within nominal group)
physical_scenario  anisotropy  binary_contamination  contraction  expansion  galactic_tidal_shear   none  perspective  shear  substructure
rv_fraction                                                                                                                               
0.2                     0.055                 0.027        0.205      0.027                 0.027  0.274        0.096  0.055         0.233
0.4                     0.030                 0.212        0.212      0.015                 0.030  0.227        0.015  0.152         0.106
0.6                     0.069                 0.139        0.030      0.139                 0.020  0.297        0.050  0.208         0.050
0.8                     0.191                 0.103        0.000      0.221                 0.044  0.074        0.044  0.235         0.088
1.0                     0.115                 0.058        0.192      0.135                 0.019  0.058        0.058  0.096         0.269

## Reproducible products
`analysis/r1_synthetic_recovery_audit.py` reads the frozen existing design and results and writes `results/r1/synthetic_recovery_calibration.csv`.
